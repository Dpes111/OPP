-- ============================================================
-- STAFF & OPERATIONS MANAGEMENT SYSTEM — SUPABASE SCHEMA
-- ============================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'staff');
CREATE TYPE task_type AS ENUM ('bank', 'delivery', 'party');
CREATE TYPE task_status AS ENUM ('pending', 'assigned', 'in_progress', 'completed', 'cancelled');

-- ============================================================
-- PROFILES TABLE (extends Supabase auth.users)
-- ============================================================
CREATE TABLE profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name     TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  role          user_role NOT NULL DEFAULT 'staff',
  avatar_url    TEXT,
  phone         TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TASKS TABLE
-- ============================================================
CREATE TABLE tasks (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title           TEXT NOT NULL,
  type            task_type NOT NULL,
  description     TEXT,
  location_name   TEXT NOT NULL,
  latitude        DOUBLE PRECISION NOT NULL,
  longitude       DOUBLE PRECISION NOT NULL,
  assigned_to     UUID REFERENCES profiles(id) ON DELETE SET NULL,
  assigned_by     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status          task_status NOT NULL DEFAULT 'pending',
  due_date        TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ATTENDANCE LOGS TABLE
-- ============================================================
CREATE TABLE attendance_logs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  staff_id        UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  task_id         UUID REFERENCES tasks(id) ON DELETE SET NULL,
  check_in_time   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  check_in_lat    DOUBLE PRECISION NOT NULL,
  check_in_lng    DOUBLE PRECISION NOT NULL,
  distance_meters DOUBLE PRECISION,
  is_within_fence BOOLEAN NOT NULL DEFAULT false,
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- MESSAGES TABLE (Hub-and-Spoke: Staff ↔ Manager/Admin only)
-- ============================================================
CREATE TABLE messages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id   UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  is_read     BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Enforce hub-and-spoke: prevent staff-to-staff
  CONSTRAINT no_staff_to_staff CHECK (
    sender_id != receiver_id
  )
);

-- ============================================================
-- PUSH SUBSCRIPTIONS TABLE
-- ============================================================
CREATE TABLE push_subscriptions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  endpoint    TEXT NOT NULL,
  p256dh      TEXT NOT NULL,
  auth        TEXT NOT NULL,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, endpoint)
);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_tasks_updated_at
  BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    NEW.email,
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'staff')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- Helper: get current user role
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- PROFILES RLS
CREATE POLICY "profiles_select" ON profiles FOR SELECT
  USING (
    auth.uid() = id OR
    get_my_role() IN ('admin', 'manager')
  );

CREATE POLICY "profiles_insert_admin" ON profiles FOR INSERT
  WITH CHECK (get_my_role() = 'admin');

CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  USING (auth.uid() = id OR get_my_role() = 'admin');

CREATE POLICY "profiles_delete_admin" ON profiles FOR DELETE
  USING (get_my_role() = 'admin');

-- TASKS RLS
CREATE POLICY "tasks_select" ON tasks FOR SELECT
  USING (
    get_my_role() IN ('admin', 'manager') OR
    assigned_to = auth.uid()
  );

CREATE POLICY "tasks_insert_manager" ON tasks FOR INSERT
  WITH CHECK (get_my_role() IN ('admin', 'manager'));

CREATE POLICY "tasks_update" ON tasks FOR UPDATE
  USING (
    get_my_role() IN ('admin', 'manager') OR
    (assigned_to = auth.uid() AND status IN ('assigned', 'in_progress'))
  );

CREATE POLICY "tasks_delete_admin" ON tasks FOR DELETE
  USING (get_my_role() IN ('admin', 'manager'));

-- ATTENDANCE LOGS RLS
CREATE POLICY "attendance_select" ON attendance_logs FOR SELECT
  USING (
    get_my_role() IN ('admin', 'manager') OR
    staff_id = auth.uid()
  );

CREATE POLICY "attendance_insert_own" ON attendance_logs FOR INSERT
  WITH CHECK (staff_id = auth.uid());

-- MESSAGES RLS (Hub-and-Spoke enforcement)
CREATE POLICY "messages_select" ON messages FOR SELECT
  USING (sender_id = auth.uid() OR receiver_id = auth.uid());

CREATE POLICY "messages_insert" ON messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid() AND
    -- Staff can only message managers/admins
    (
      get_my_role() IN ('admin', 'manager') OR
      (
        get_my_role() = 'staff' AND
        (SELECT role FROM profiles WHERE id = receiver_id) IN ('admin', 'manager')
      )
    )
  );

-- PUSH SUBSCRIPTIONS RLS
CREATE POLICY "push_select_own" ON push_subscriptions FOR SELECT
  USING (user_id = auth.uid() OR get_my_role() IN ('admin', 'manager'));

CREATE POLICY "push_insert_own" ON push_subscriptions FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "push_delete_own" ON push_subscriptions FOR DELETE
  USING (user_id = auth.uid() OR get_my_role() = 'admin');

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================
CREATE INDEX idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_type ON tasks(type);
CREATE INDEX idx_attendance_staff_id ON attendance_logs(staff_id);
CREATE INDEX idx_attendance_task_id ON attendance_logs(task_id);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_receiver ON messages(receiver_id);
CREATE INDEX idx_push_user_id ON push_subscriptions(user_id);

-- ============================================================
-- REALTIME PUBLICATIONS
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE attendance_logs;

-- ============================================================
-- SEED: Default Admin User (update email/password via Supabase dashboard)
-- Run AFTER creating user in Supabase Auth dashboard
-- UPDATE profiles SET role = 'admin' WHERE email = 'admin@yourcompany.com';
-- ============================================================

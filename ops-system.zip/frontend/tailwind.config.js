/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,jsx}',
    './src/components/**/*.{js,jsx}',
    './src/app/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        // OpsSystem dark theme palette
        'ops-bg':       '#080c18',
        'ops-surface':  '#0d1526',
        'ops-card':     '#111827',
        'ops-border':   '#1e2d47',
        'ops-cyan':     '#00d4ff',
        'ops-cyan-dim': '#0099bb',
        'ops-amber':    '#f59e0b',
        'ops-green':    '#10b981',
        'ops-red':      '#ef4444',
        'ops-purple':   '#8b5cf6',
        'ops-text':     '#e2e8f0',
        'ops-muted':    '#64748b',
      },
      fontFamily: {
        sans: ['IBM Plex Sans', 'system-ui', 'sans-serif'],
        mono: ['IBM Plex Mono', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-up': 'slideUp 0.3s ease-out',
        'fade-in': 'fadeIn 0.2s ease-out',
      },
      keyframes: {
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};

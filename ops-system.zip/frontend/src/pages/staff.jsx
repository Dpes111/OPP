// src/pages/staff.jsx — Manager: View All Staff + Workload
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { Users, CheckSquare, MessageSquare, Activity, Circle } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { LoadingSpinner } from '../components/shared/Cards';
import { useAuth } from '../hooks/useAuth';
import { getUsers } from '../lib/api';
import { useTasks } from '../hooks/useTasks';

export default function StaffPage() {
  const router = useRouter();
  const { profile, token, loading: authLoading } = useAuth();
  const { tasks, workload, loading: tasksLoading } = useTasks();
  const [staff, setStaff]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !profile) router.replace('/');
    if (profile && profile.role === 'staff') router.replace('/dashboard');
  }, [profile, authLoading, router]);

  const fetchStaff = useCallback(async () => {
    if (!token) return;
    try {
      const { users } = await getUsers(token);
      setStaff(users.filter(u => u.role === 'staff' && u.is_active));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchStaff(); }, [fetchStaff]);

  const getStaffTasks = (staffId) => tasks.filter(t => t.assigned_to === staffId);
  const getActiveTasks = (staffId) => tasks.filter(t => t.assigned_to === staffId && ['assigned', 'in_progress'].includes(t.status));
  const getWorkload = (staffId) => workload.find(w => w.staff_id === staffId)?.active_count || 0;

  const statusColor = (count) => {
    if (count === 0) return 'text-ops-green';
    if (count <= 2)  return 'text-ops-cyan';
    if (count <= 4)  return 'text-ops-amber';
    return 'text-ops-red';
  };

  return (
    <Layout title="Staff Overview">
      <div className="space-y-5">
        {/* Summary bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-cyan">{staff.length}</div>
            <div className="text-xs text-ops-muted mt-1">Active Staff</div>
          </div>
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-amber">
              {tasks.filter(t => ['assigned', 'in_progress'].includes(t.status)).length}
            </div>
            <div className="text-xs text-ops-muted mt-1">Active Tasks</div>
          </div>
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-green">
              {tasks.filter(t => t.status === 'completed').length}
            </div>
            <div className="text-xs text-ops-muted mt-1">Completed</div>
          </div>
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-muted">
              {staff.filter(s => getActiveTasks(s.id).length === 0).length}
            </div>
            <div className="text-xs text-ops-muted mt-1">Available</div>
          </div>
        </div>

        {/* Staff Cards */}
        {loading || tasksLoading ? <LoadingSpinner /> : staff.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-10 h-10 text-ops-border mx-auto mb-3" />
            <p className="text-ops-muted text-sm">No staff members found</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {staff.map(member => {
              const allTasks    = getStaffTasks(member.id);
              const active      = getActiveTasks(member.id);
              const count       = getWorkload(member.id);
              const completed   = allTasks.filter(t => t.status === 'completed').length;

              return (
                <div key={member.id} className="bg-ops-card border border-ops-border rounded-xl p-5 hover:border-ops-cyan/30 transition-all">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ops-cyan/20 to-purple-500/20 border border-ops-border flex items-center justify-center">
                        <span className="text-base font-bold text-ops-text">{member.full_name?.charAt(0)}</span>
                      </div>
                      <div>
                        <div className="text-sm font-bold text-ops-text">{member.full_name}</div>
                        <div className="text-xs text-ops-muted">{member.email}</div>
                      </div>
                    </div>
                    {/* Live workload badge */}
                    <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-xs font-mono font-bold
                      ${count === 0 ? 'bg-ops-green/10 border-ops-green/30 text-ops-green' :
                        count <= 2 ? 'bg-ops-cyan/10 border-ops-cyan/30 text-ops-cyan' :
                        count <= 4 ? 'bg-ops-amber/10 border-ops-amber/30 text-ops-amber' :
                        'bg-ops-red/10 border-ops-red/30 text-ops-red'}`}>
                      <Circle className="w-2 h-2 fill-current" />
                      {count} Active
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="bg-ops-surface border border-ops-border rounded-lg p-2.5 text-center">
                      <div className={`text-lg font-bold font-mono ${statusColor(count)}`}>{count}</div>
                      <div className="text-[10px] text-ops-muted">Active</div>
                    </div>
                    <div className="bg-ops-surface border border-ops-border rounded-lg p-2.5 text-center">
                      <div className="text-lg font-bold font-mono text-ops-green">{completed}</div>
                      <div className="text-[10px] text-ops-muted">Done</div>
                    </div>
                    <div className="bg-ops-surface border border-ops-border rounded-lg p-2.5 text-center">
                      <div className="text-lg font-bold font-mono text-ops-text">{allTasks.length}</div>
                      <div className="text-[10px] text-ops-muted">Total</div>
                    </div>
                  </div>

                  {/* Active task list */}
                  {active.length > 0 && (
                    <div className="space-y-1.5 mb-4">
                      {active.slice(0, 3).map(task => (
                        <div key={task.id} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-ops-surface border border-ops-border">
                          <span className="text-xs">{task.type === 'bank' ? '🏦' : task.type === 'delivery' ? '📦' : '🎉'}</span>
                          <span className="text-xs text-ops-text truncate flex-1">{task.title}</span>
                          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded badge-${task.status}`}>
                            {task.status.replace('_', ' ')}
                          </span>
                        </div>
                      ))}
                      {active.length > 3 && (
                        <div className="text-xs text-ops-muted text-center">+{active.length - 3} more</div>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => router.push(`/tasks?assignee=${member.id}`)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-ops-muted hover:text-ops-cyan hover:bg-ops-cyan/10 border border-ops-border transition-colors"
                    >
                      <CheckSquare className="w-3.5 h-3.5" /> Tasks
                    </button>
                    <button
                      onClick={() => router.push(`/chat?partner=${member.id}`)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-ops-muted hover:text-ops-green hover:bg-ops-green/10 border border-ops-border transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" /> Message
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}

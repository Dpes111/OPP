// src/pages/checkin.jsx — Staff GPS Check-In & Task Completion
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import { MapPin, Navigation, CheckCircle2, AlertTriangle, Loader2, Clock } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { LoadingSpinner } from '../components/shared/Cards';
import { useAuth } from '../hooks/useAuth';
import { useTasks } from '../hooks/useTasks';
import { checkIn, completeTask, getCurrentPosition } from '../lib/api';

// SSR-safe map
const LiveMap = dynamic(() => import('../components/shared/LiveMap'), {
  ssr: false,
  loading: () => <div className="h-64 bg-ops-surface rounded-xl border border-ops-border flex items-center justify-center"><Loader2 className="w-5 h-5 text-ops-cyan animate-spin" /></div>
});

export default function CheckInPage() {
  const router = useRouter();
  const { profile, token, loading: authLoading } = useAuth();
  const { activeTasks, loading: tasksLoading, refetch } = useTasks();

  const [gps, setGps]         = useState(null);
  const [gpsError, setGpsErr] = useState('');
  const [gettingGps, setGettingGps] = useState(false);
  const [selectedTask, setSelectedTask] = useState('');
  const [result, setResult]   = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { if (!authLoading && !profile) router.replace('/'); }, [profile, authLoading, router]);

  const getGPS = async () => {
    setGettingGps(true); setGpsErr(''); setResult(null);
    try {
      const pos = await getCurrentPosition();
      setGps({ lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy });
    } catch (e) {
      setGpsErr('Could not get location. Please enable GPS and try again.');
    } finally {
      setGettingGps(false);
    }
  };

  const handleCheckIn = async () => {
    if (!gps) return;
    setSubmitting(true);
    try {
      const res = await checkIn({ task_id: selectedTask || undefined, latitude: gps.lat, longitude: gps.lng }, token);
      setResult({ type: res.geofence.isWithin ? 'success' : 'warning', message: res.message, distance: res.geofence.distanceMeters });
    } catch (e) {
      setResult({ type: 'error', message: e.message });
    } finally {
      setSubmitting(false);
    }
  };

  const handleComplete = async () => {
    if (!gps || !selectedTask) return;
    setSubmitting(true);
    try {
      const res = await completeTask({ task_id: selectedTask, latitude: gps.lat, longitude: gps.lng }, token);
      setResult({ type: 'success', message: res.message });
      refetch();
    } catch (e) {
      setResult({ type: 'error', message: e.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading || tasksLoading) return <Layout title="GPS Check-In"><LoadingSpinner /></Layout>;

  const selectedTaskObj = activeTasks.find(t => t.id === selectedTask);

  return (
    <Layout title="GPS Check-In">
      <div className="max-w-lg mx-auto space-y-5">

        {/* Header */}
        <div className="bg-ops-card border border-ops-border rounded-xl p-5">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-ops-cyan/10 border border-ops-cyan/30 flex items-center justify-center">
              <Navigation className="w-5 h-5 text-ops-cyan" />
            </div>
            <div>
              <h2 className="font-bold text-ops-text">GPS Check-In</h2>
              <p className="text-xs text-ops-muted">Must be within 100m of task location</p>
            </div>
          </div>
        </div>

        {/* Task Selector */}
        {activeTasks.length > 0 && (
          <div className="bg-ops-card border border-ops-border rounded-xl p-5">
            <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-3 block">Select Task (Optional)</label>
            <div className="space-y-2">
              <button
                onClick={() => setSelectedTask('')}
                className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-colors
                  ${!selectedTask ? 'bg-ops-cyan/10 border-ops-cyan/30 text-ops-cyan' : 'border-ops-border text-ops-muted hover:border-ops-muted'}`}
              >
                General Check-In (no specific task)
              </button>
              {activeTasks.map(task => (
                <button
                  key={task.id}
                  onClick={() => setSelectedTask(task.id)}
                  className={`w-full text-left px-4 py-3 rounded-xl border transition-colors
                    ${selectedTask === task.id ? 'bg-ops-cyan/10 border-ops-cyan/30' : 'border-ops-border hover:border-ops-muted'}`}
                >
                  <div className="text-sm font-medium text-ops-text">{task.title}</div>
                  <div className="text-xs text-ops-muted mt-0.5 flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {task.location_name}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTasks.length === 0 && (
          <div className="bg-ops-card border border-ops-border rounded-xl p-8 text-center">
            <CheckCircle2 className="w-10 h-10 text-ops-green mx-auto mb-2" />
            <p className="text-ops-text font-medium">No active tasks</p>
            <p className="text-sm text-ops-muted mt-1">You can still do a general GPS check-in.</p>
          </div>
        )}

        {/* GPS Action */}
        <div className="bg-ops-card border border-ops-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-ops-text">Your Location</span>
            {gps && (
              <span className="text-xs font-mono text-ops-green">
                ±{Math.round(gps.accuracy)}m accuracy
              </span>
            )}
          </div>

          {gps ? (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-ops-surface border border-ops-border font-mono text-xs text-ops-cyan">
                <div>LAT: {gps.lat.toFixed(6)}</div>
                <div>LNG: {gps.lng.toFixed(6)}</div>
                <div className="flex items-center gap-1 mt-1 text-ops-green">
                  <Clock className="w-3 h-3" />
                  {new Date().toLocaleTimeString()}
                </div>
              </div>
              <LiveMap
                userLat={gps.lat} userLng={gps.lng}
                taskLat={selectedTaskObj?.latitude}
                taskLng={selectedTaskObj?.longitude}
                taskLabel={selectedTaskObj?.location_name}
              />
            </div>
          ) : (
            <button
              onClick={getGPS} disabled={gettingGps}
              className="w-full py-3 rounded-xl bg-ops-cyan/10 border border-ops-cyan/30 text-ops-cyan text-sm font-semibold hover:bg-ops-cyan/20 transition-colors flex items-center justify-center gap-2"
            >
              {gettingGps ? <><Loader2 className="w-4 h-4 animate-spin" /> Getting GPS…</> : <><Navigation className="w-4 h-4" /> Get My Location</>}
            </button>
          )}

          {gpsError && (
            <div className="flex items-center gap-2 text-xs text-ops-red bg-ops-red/10 border border-ops-red/30 rounded-lg px-3 py-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {gpsError}
            </div>
          )}

          {/* Result */}
          {result && (
            <div className={`flex items-start gap-2 text-sm px-3 py-3 rounded-xl border
              ${result.type === 'success' ? 'bg-ops-green/10 border-ops-green/30 text-ops-green' :
                result.type === 'warning' ? 'bg-ops-amber/10 border-ops-amber/30 text-ops-amber' :
                'bg-ops-red/10 border-ops-red/30 text-ops-red'}`}
            >
              {result.type === 'success' ? <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />}
              {result.message}
            </div>
          )}

          {/* Action buttons */}
          {gps && (
            <div className="flex gap-3">
              <button
                onClick={handleCheckIn} disabled={submitting}
                className="flex-1 py-2.5 rounded-xl bg-ops-surface border border-ops-border text-ops-text text-sm font-medium hover:border-ops-cyan/40 transition-colors flex items-center justify-center gap-2"
              >
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
                Check In
              </button>
              {selectedTask && (
                <button
                  onClick={handleComplete} disabled={submitting}
                  className="flex-1 py-2.5 rounded-xl bg-ops-green text-white text-sm font-semibold hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Complete Task
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

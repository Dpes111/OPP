// src/pages/tasks.jsx — Full Task Management Page
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Plus, Filter, Search, Trash2, Edit, CheckCircle, XCircle, Building2, Package, PartyPopper } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { TaskCard, LoadingSpinner, EmptyState } from '../components/shared/Cards';
import TaskModal from '../components/manager/TaskModal';
import { useAuth } from '../hooks/useAuth';
import { useTasks } from '../hooks/useTasks';
import { deleteTask, updateTask } from '../lib/api';

const TYPE_ICONS = { bank: Building2, delivery: Package, party: PartyPopper };
const STATUS_TABS = [
  { key: 'all',        label: 'All' },
  { key: 'assigned',   label: 'Assigned' },
  { key: 'in_progress',label: 'In Progress' },
  { key: 'completed',  label: 'Completed' },
  { key: 'pending',    label: 'Pending' },
];

export default function TasksPage() {
  const router = useRouter();
  const { profile, token, loading: authLoading } = useAuth();
  const { tasks, loading, refetch } = useTasks();
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter]     = useState('all');
  const [search, setSearch]             = useState('');
  const [showModal, setShowModal]       = useState(false);
  const [editTask, setEditTask]         = useState(null);

  useEffect(() => { if (!authLoading && !profile) router.replace('/'); }, [profile, authLoading, router]);

  const filtered = tasks.filter(t => {
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (typeFilter   !== 'all' && t.type   !== typeFilter)   return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) &&
        !t.location_name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const handleDelete = async (id) => {
    if (!confirm('Delete this task?')) return;
    await deleteTask(id, token);
    refetch();
  };

  const handleStatusChange = async (id, status) => {
    await updateTask(id, { status }, token);
    refetch();
  };

  const canManage = profile?.role !== 'staff';

  return (
    <Layout title="Task Management">
      <div className="space-y-5">
        {/* Header */}
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ops-muted" />
            <input
              value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search tasks or locations…"
              className="w-full bg-ops-card border border-ops-border rounded-xl pl-10 pr-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
            />
          </div>
          {canManage && (
            <button
              onClick={() => { setEditTask(null); setShowModal(true); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-ops-cyan text-ops-bg text-sm font-semibold hover:bg-ops-cyan-dim transition-colors whitespace-nowrap"
            >
              <Plus className="w-4 h-4" /> Assign Task
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          {/* Status tabs */}
          <div className="flex gap-1 bg-ops-card border border-ops-border rounded-xl p-1">
            {STATUS_TABS.map(({ key, label }) => (
              <button key={key} onClick={() => setStatusFilter(key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors
                  ${statusFilter === key ? 'bg-ops-cyan text-ops-bg' : 'text-ops-muted hover:text-ops-text'}`}>
                {label}
                {key !== 'all' && (
                  <span className="ml-1.5 opacity-60">
                    {tasks.filter(t => t.status === key).length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Type filter */}
          <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
            className="bg-ops-card border border-ops-border rounded-xl px-3 py-1.5 text-xs text-ops-text focus:outline-none focus:border-ops-cyan">
            <option value="all">All Types</option>
            <option value="bank">🏦 Bank</option>
            <option value="delivery">📦 Delivery</option>
            <option value="party">🎉 Party</option>
          </select>
        </div>

        {/* Tasks List */}
        {loading ? <LoadingSpinner text="Loading tasks…" /> : filtered.length === 0 ? (
          <EmptyState
            icon={CheckCircle}
            title="No tasks found"
            description={search ? 'Try adjusting your search or filters.' : 'No tasks match the current filter.'}
            action={canManage && (
              <button onClick={() => setShowModal(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-ops-cyan text-ops-bg text-sm font-semibold">
                <Plus className="w-4 h-4" /> Create First Task
              </button>
            )}
          />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map(task => {
              const TypeIcon = TYPE_ICONS[task.type];
              return (
                <div key={task.id} className="bg-ops-card border border-ops-border rounded-xl p-4 hover:border-ops-cyan/40 transition-all group">
                  {/* Task type + status */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {TypeIcon && <TypeIcon className="w-4 h-4 text-ops-muted" />}
                      <span className="text-xs text-ops-muted font-mono uppercase">{task.type}</span>
                    </div>
                    <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full badge-${task.status}`}>
                      {task.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 className="text-sm font-semibold text-ops-text mb-1">{task.title}</h3>
                  {task.description && (
                    <p className="text-xs text-ops-muted mb-2 line-clamp-2">{task.description}</p>
                  )}

                  <div className="text-xs text-ops-muted mb-3">📍 {task.location_name}</div>

                  {task.assigned_to_profile && (
                    <div className="flex items-center gap-2 mb-3 p-2 rounded-lg bg-ops-surface border border-ops-border">
                      <div className="w-5 h-5 rounded-md bg-ops-border flex items-center justify-center">
                        <span className="text-[9px] font-bold">{task.assigned_to_profile.full_name?.charAt(0)}</span>
                      </div>
                      <span className="text-xs text-ops-text">{task.assigned_to_profile.full_name}</span>
                    </div>
                  )}

                  {task.due_date && (
                    <div className="text-[10px] text-ops-muted font-mono mb-3">
                      Due: {new Date(task.due_date).toLocaleString()}
                    </div>
                  )}

                  {/* Actions */}
                  {canManage && (
                    <div className="flex gap-2 pt-2 border-t border-ops-border opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => { setEditTask(task); setShowModal(true); }}
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-ops-muted hover:text-ops-cyan hover:bg-ops-cyan/10 text-xs transition-colors">
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                      {task.status === 'assigned' && (
                        <button onClick={() => handleStatusChange(task.id, 'cancelled')}
                          className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-ops-muted hover:text-ops-red hover:bg-ops-red/10 text-xs transition-colors">
                          <XCircle className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button onClick={() => handleDelete(task.id)}
                        className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-ops-muted hover:text-ops-red hover:bg-ops-red/10 text-xs transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <TaskModal
          task={editTask}
          onClose={() => { setShowModal(false); setEditTask(null); }}
          onSaved={refetch}
        />
      )}
    </Layout>
  );
}

// src/pages/logs.jsx — Attendance & Activity Logs
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { MapPin, CheckCircle2, XCircle, Clock, User, Activity, Filter } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { LoadingSpinner } from '../components/shared/Cards';
import { useAuth } from '../hooks/useAuth';
import { getAttendanceLogs } from '../lib/api';

export default function LogsPage() {
  const router = useRouter();
  const { profile, token, loading: authLoading } = useAuth();
  const [logs, setLogs]         = useState([]);
  const [loading, setLoading]   = useState(true);
  const [filter, setFilter]     = useState('all'); // all | within | outside

  useEffect(() => { if (!authLoading && !profile) router.replace('/'); }, [profile, authLoading, router]);

  const fetchLogs = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const { logs: l } = await getAttendanceLogs(token);
      setLogs(l || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const filtered = logs.filter(l => {
    if (filter === 'within')  return l.is_within_fence;
    if (filter === 'outside') return !l.is_within_fence;
    return true;
  });

  const withinCount  = logs.filter(l => l.is_within_fence).length;
  const outsideCount = logs.filter(l => !l.is_within_fence).length;

  return (
    <Layout title="Attendance Logs">
      <div className="space-y-5">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-text">{logs.length}</div>
            <div className="text-xs text-ops-muted mt-1">Total Check-ins</div>
          </div>
          <div className="bg-ops-card border border-ops-green/30 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-green">{withinCount}</div>
            <div className="text-xs text-ops-muted mt-1">Within Fence</div>
          </div>
          <div className="bg-ops-card border border-ops-red/30 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-red">{outsideCount}</div>
            <div className="text-xs text-ops-muted mt-1">Outside Fence</div>
          </div>
        </div>

        {/* Filter */}
        <div className="flex gap-2">
          {[
            { key: 'all',     label: 'All Logs' },
            { key: 'within',  label: '✅ Within Fence' },
            { key: 'outside', label: '⚠️ Outside Fence' },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setFilter(key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors border
                ${filter === key ? 'bg-ops-cyan/10 border-ops-cyan/30 text-ops-cyan' : 'border-ops-border text-ops-muted hover:text-ops-text'}`}>
              {label}
            </button>
          ))}
        </div>

        {/* Logs */}
        {loading ? <LoadingSpinner text="Loading logs…" /> : filtered.length === 0 ? (
          <div className="text-center py-16 text-ops-muted">
            <Activity className="w-10 h-10 mx-auto mb-3 text-ops-border" />
            <p className="text-sm">No attendance logs yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(log => (
              <div key={log.id} className="bg-ops-card border border-ops-border rounded-xl p-4 flex items-start gap-4 hover:border-ops-cyan/20 transition-colors">
                {/* Fence indicator */}
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5
                  ${log.is_within_fence ? 'bg-ops-green/10 border border-ops-green/30' : 'bg-ops-red/10 border border-ops-red/30'}`}>
                  {log.is_within_fence
                    ? <CheckCircle2 className="w-4 h-4 text-ops-green" />
                    : <XCircle className="w-4 h-4 text-ops-red" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {profile?.role !== 'staff' && log.staff && (
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-md bg-ops-border flex items-center justify-center">
                          <span className="text-[9px] font-bold">{log.staff.full_name?.charAt(0)}</span>
                        </div>
                        <span className="text-sm font-semibold text-ops-text">{log.staff.full_name}</span>
                      </div>
                    )}
                    {log.task && (
                      <span className="text-xs text-ops-muted bg-ops-surface border border-ops-border px-2 py-0.5 rounded-full">
                        {log.task.title}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-4 mt-2">
                    <div className="flex items-center gap-1 text-xs text-ops-muted">
                      <Clock className="w-3 h-3" />
                      {new Date(log.check_in_time).toLocaleString()}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-ops-muted font-mono">
                      <MapPin className="w-3 h-3" />
                      {log.check_in_lat.toFixed(5)}, {log.check_in_lng.toFixed(5)}
                    </div>
                    <div className={`flex items-center gap-1 text-xs font-mono font-bold
                      ${log.is_within_fence ? 'text-ops-green' : 'text-ops-red'}`}>
                      {log.distance_meters !== null && `${log.distance_meters}m from target`}
                    </div>
                  </div>

                  {log.notes && (
                    <div className="mt-1.5 text-xs text-ops-muted italic">{log.notes}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

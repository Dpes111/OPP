// src/pages/users.jsx — Admin User Management
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { Plus, UserCheck, UserX, Shield, Activity, Users, Search, X, Loader2, Eye, EyeOff } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { LoadingSpinner } from '../components/shared/Cards';
import { useAuth } from '../hooks/useAuth';
import { getUsers, createUser, updateUser, deactivateUser } from '../lib/api';

const ROLE_CONFIG = {
  admin:   { label: 'Admin',   icon: Shield,   color: 'text-ops-red',    bg: 'bg-ops-red/10',    border: 'border-ops-red/30'   },
  manager: { label: 'Manager', icon: Activity, color: 'text-ops-amber',  bg: 'bg-ops-amber/10',  border: 'border-ops-amber/30' },
  staff:   { label: 'Staff',   icon: Users,    color: 'text-ops-cyan',   bg: 'bg-ops-cyan/10',   border: 'border-ops-cyan/30'  },
};

function UserModal({ onClose, onSaved, token }) {
  const [form, setForm] = useState({ full_name: '', email: '', password: '', role: 'staff', phone: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');
  const [showPwd, setShowPwd] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.full_name || !form.email || !form.password) return setError('All fields required');
    if (form.password.length < 8) return setError('Password must be at least 8 characters');
    setSaving(true); setError('');
    try {
      await createUser(form, token);
      onSaved(); onClose();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-ops-surface border border-ops-border rounded-2xl w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-5 border-b border-ops-border">
          <h2 className="font-bold text-ops-text">Create New User</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-ops-muted hover:text-ops-text" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {[
            { key: 'full_name', label: 'Full Name', type: 'text',     placeholder: 'John Doe' },
            { key: 'email',     label: 'Email',     type: 'email',    placeholder: 'john@company.com' },
            { key: 'phone',     label: 'Phone',     type: 'tel',      placeholder: '+977 98XXXXXXXX' },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key}>
              <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-1.5 block">{label}</label>
              <input type={type} value={form[key]} onChange={e => set(key, e.target.value)} placeholder={placeholder}
                className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan" />
            </div>
          ))}

          <div>
            <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-1.5 block">Password</label>
            <div className="relative">
              <input type={showPwd ? 'text' : 'password'} value={form.password} onChange={e => set('password', e.target.value)}
                placeholder="Min. 8 characters"
                className="w-full bg-ops-card border border-ops-border rounded-xl px-4 pr-10 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan" />
              <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ops-muted">
                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-2 block">Role</label>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(ROLE_CONFIG).map(([value, { label, icon: Icon, color, bg, border }]) => (
                <button key={value} type="button" onClick={() => set('role', value)}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all
                    ${form.role === value ? `${bg} ${border}` : 'border-ops-border bg-ops-card hover:border-ops-muted'}`}>
                  <Icon className={`w-4 h-4 ${form.role === value ? color : 'text-ops-muted'}`} />
                  <span className={`text-xs font-medium ${form.role === value ? color : 'text-ops-muted'}`}>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {error && <div className="text-xs text-ops-red bg-ops-red/10 border border-ops-red/30 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl border border-ops-border text-ops-muted hover:text-ops-text text-sm font-medium transition-colors">
              Cancel
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 px-4 py-2.5 rounded-xl bg-ops-cyan text-ops-bg font-semibold text-sm hover:bg-ops-cyan-dim transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" />Creating…</> : 'Create User'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function UsersPage() {
  const router = useRouter();
  const { profile, token, loading: authLoading } = useAuth();
  const [users, setUsers]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [showModal, setShowModal]   = useState(false);

  useEffect(() => {
    if (!authLoading && !profile) router.replace('/');
    if (profile && profile.role !== 'admin') router.replace('/dashboard');
  }, [profile, authLoading, router]);

  const fetchUsers = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try { const { users: u } = await getUsers(token); setUsers(u || []); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleToggle = async (id, is_active) => {
    if (!is_active) { await deactivateUser(id, token); }
    else { await updateUser(id, { is_active: true }, token); }
    fetchUsers();
  };

  const filtered = users.filter(u => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (search && !u.full_name.toLowerCase().includes(search.toLowerCase()) &&
        !u.email.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <Layout title="User Management">
      <div className="space-y-5">
        {/* Header */}
        <div className="flex gap-3 flex-wrap items-center">
          <div className="flex-1 relative min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ops-muted" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users…"
              className="w-full bg-ops-card border border-ops-border rounded-xl pl-10 pr-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan" />
          </div>
          <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)}
            className="bg-ops-card border border-ops-border rounded-xl px-3 py-2.5 text-sm text-ops-text focus:outline-none focus:border-ops-cyan">
            <option value="all">All Roles</option>
            <option value="admin">Admin</option>
            <option value="manager">Manager</option>
            <option value="staff">Staff</option>
          </select>
          <button onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-ops-cyan text-ops-bg text-sm font-semibold hover:bg-ops-cyan-dim transition-colors">
            <Plus className="w-4 h-4" /> Add User
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {Object.entries(ROLE_CONFIG).map(([role, { label, icon: Icon, color, bg, border }]) => {
            const count = users.filter(u => u.role === role && u.is_active).length;
            return (
              <div key={role} className={`${bg} border ${border} rounded-xl p-4 flex items-center gap-3`}>
                <Icon className={`w-5 h-5 ${color}`} />
                <div>
                  <div className={`text-xl font-bold font-mono ${color}`}>{count}</div>
                  <div className="text-xs text-ops-muted">{label}s</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Users Table */}
        {loading ? <LoadingSpinner /> : (
          <div className="bg-ops-card border border-ops-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-ops-border">
                    {['User', 'Role', 'Contact', 'Status', 'Joined', 'Actions'].map(h => (
                      <th key={h} className="text-left text-xs text-ops-muted uppercase tracking-wider font-medium px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-ops-border">
                  {filtered.map(user => {
                    const rc = ROLE_CONFIG[user.role];
                    const RIcon = rc?.icon || Users;
                    return (
                      <tr key={user.id} className="hover:bg-ops-surface/50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-ops-border flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-bold text-ops-text">{user.full_name?.charAt(0)}</span>
                            </div>
                            <div>
                              <div className="text-sm font-medium text-ops-text">{user.full_name}</div>
                              <div className="text-xs text-ops-muted">{user.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${rc?.bg} ${rc?.color} border ${rc?.border}`}>
                            <RIcon className="w-3 h-3" /> {rc?.label}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs text-ops-muted">{user.phone || '—'}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${user.is_active ? 'text-ops-green bg-ops-green/10 border border-ops-green/30' : 'text-ops-red bg-ops-red/10 border border-ops-red/30'}`}>
                            {user.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs text-ops-muted font-mono">
                          {new Date(user.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3">
                          {user.id !== profile?.id && (
                            <button
                              onClick={() => handleToggle(user.id, !user.is_active)}
                              className={`flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg transition-colors
                                ${user.is_active
                                  ? 'text-ops-red hover:bg-ops-red/10'
                                  : 'text-ops-green hover:bg-ops-green/10'}`}
                            >
                              {user.is_active ? <><UserX className="w-3.5 h-3.5" />Deactivate</> : <><UserCheck className="w-3.5 h-3.5" />Activate</>}
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filtered.length === 0 && (
                <div className="text-center py-12 text-ops-muted text-sm">No users found</div>
              )}
            </div>
          </div>
        )}
      </div>

      {showModal && <UserModal token={token} onClose={() => setShowModal(false)} onSaved={fetchUsers} />}
    </Layout>
  );
}

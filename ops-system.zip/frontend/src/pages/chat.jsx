// src/pages/chat.jsx — Professional Hub-and-Spoke Chat
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Layout from '../components/shared/Layout';
import ChatPanel, { ConversationList } from '../components/shared/ChatPanel';
import { useAuth } from '../hooks/useAuth';

export default function ChatPage() {
  const router = useRouter();
  const { profile, loading: authLoading } = useAuth();
  const [partnerId, setPartnerId]     = useState(null);
  const [partnerName, setPartnerName] = useState('');

  useEffect(() => { if (!authLoading && !profile) router.replace('/'); }, [profile, authLoading, router]);

  return (
    <Layout title="Messages">
      <div className="h-[calc(100vh-8rem)] flex rounded-2xl overflow-hidden border border-ops-border bg-ops-card">
        {/* Contacts sidebar */}
        <div className="w-64 border-r border-ops-border flex-shrink-0 hidden sm:block">
          <ConversationList
            selectedId={partnerId}
            onSelect={(id, name) => { setPartnerId(id); setPartnerName(name); }}
          />
        </div>

        {/* Mobile: show list if no conversation selected */}
        <div className="sm:hidden w-full">
          {!partnerId ? (
            <ConversationList
              selectedId={partnerId}
              onSelect={(id, name) => { setPartnerId(id); setPartnerName(name); }}
            />
          ) : (
            <div className="flex flex-col h-full">
              <button
                onClick={() => setPartnerId(null)}
                className="px-4 py-2 text-xs text-ops-cyan border-b border-ops-border text-left hover:bg-ops-surface"
              >
                ← Back to contacts
              </button>
              <div className="flex-1 overflow-hidden">
                <ChatPanel partnerId={partnerId} partnerName={partnerName} />
              </div>
            </div>
          )}
        </div>

        {/* Desktop: chat area */}
        <div className="flex-1 hidden sm:block overflow-hidden">
          <ChatPanel partnerId={partnerId} partnerName={partnerName} />
        </div>
      </div>
    </Layout>
  );
}

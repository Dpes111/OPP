// src/pages/dashboard.jsx — Role-Adaptive Dashboard
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { CheckSquare, Clock, Users, Activity, Building2, Package, PartyPopper, TrendingUp, MapPin, AlertCircle } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { StatCard, WorkloadBadge, TaskCard, LoadingSpinner } from '../components/shared/Cards';
import { useAuth } from '../hooks/useAuth';
import { useTasks } from '../hooks/useTasks';

export default function Dashboard() {
  const router = useRouter();
  const { profile, loading: authLoading } = useAuth();
  const { tasks, tasksByStatus, activeTasks, workload, loading } = useTasks();

  useEffect(() => {
    if (!authLoading && !profile) router.replace('/');
  }, [profile, authLoading, router]);

  if (authLoading || !profile) return null;

  const totalTasks     = tasks.length;
  const completedToday = tasks.filter(t => t.completed_at && new Date(t.completed_at).toDateString() === new Date().toDateString()).length;
  const bankTasks      = tasks.filter(t => t.type === 'bank').length;
  const deliveryTasks  = tasks.filter(t => t.type === 'delivery').length;
  const partyTasks     = tasks.filter(t => t.type === 'party').length;

  return (
    <Layout title={profile.role === 'staff' ? 'My Tasks' : 'Operations Dashboard'}>
      {loading ? <LoadingSpinner text="Loading dashboard…" /> : (
        <div className="space-y-6 animate-fade-in">

          {/* Welcome */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-ops-text">
                Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},{' '}
                <span className="text-ops-cyan">{profile.full_name.split(' ')[0]}</span>
              </h2>
              <p className="text-sm text-ops-muted mt-0.5">
                {profile.role === 'staff'
                  ? `You have ${activeTasks.length} active task${activeTasks.length !== 1 ? 's' : ''}`
                  : `${tasks.length} total tasks across all staff`}
              </p>
            </div>
            {profile.role !== 'staff' && (
              <button
                onClick={() => router.push('/tasks')}
                className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-ops-cyan text-ops-bg text-sm font-semibold hover:bg-ops-cyan-dim transition-colors"
              >
                <CheckSquare className="w-4 h-4" /> Assign Task
              </button>
            )}
          </div>

          {/* ── ADMIN / MANAGER VIEW ── */}
          {profile.role !== 'staff' && (
            <>
              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Total Tasks"    value={totalTasks}               icon={CheckSquare} color="cyan"   sublabel="All time" />
                <StatCard label="Active"         value={activeTasks.length}        icon={Activity}    color="amber"  sublabel="In progress" />
                <StatCard label="Completed Today" value={completedToday}           icon={TrendingUp}  color="green"  sublabel="Today" />
                <StatCard label="Staff Members"  value={workload.length}           icon={Users}       color="purple" sublabel="Active" />
              </div>

              {/* Task Type Breakdown */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  { type: 'bank',     count: bankTasks,     label: 'Bank Deposits', icon: Building2,   color: 'amber' },
                  { type: 'delivery', count: deliveryTasks, label: 'Deliveries',    icon: Package,     color: 'cyan'  },
                  { type: 'party',    count: partyTasks,    label: 'Party Visits',  icon: PartyPopper, color: 'purple'},
                ].map(({ label, count, icon: Icon, color }) => (
                  <div key={label} className="bg-ops-card border border-ops-border rounded-xl p-4 flex flex-col items-center gap-2 text-center">
                    <StatCard label={label} value={count} icon={Icon} color={color} />
                  </div>
                ))}
              </div>

              {/* Staff Workload */}
              <div className="bg-ops-card border border-ops-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-ops-text flex items-center gap-2">
                    <Users className="w-4 h-4 text-ops-cyan" /> Staff Workload
                  </h3>
                  <span className="text-xs text-ops-muted font-mono">{workload.length} staff</span>
                </div>
                {workload.length === 0 ? (
                  <p className="text-sm text-ops-muted text-center py-4">No active staff assignments</p>
                ) : (
                  <div className="space-y-2">
                    {workload
                      .sort((a, b) => b.active_count - a.active_count)
                      .map(w => <WorkloadBadge key={w.staff_id} name={w.full_name} count={w.active_count} />)}
                  </div>
                )}
              </div>

              {/* Recent Tasks */}
              <div className="bg-ops-card border border-ops-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-ops-text flex items-center gap-2">
                    <Clock className="w-4 h-4 text-ops-cyan" /> Recent Tasks
                  </h3>
                  <button onClick={() => router.push('/tasks')} className="text-xs text-ops-cyan hover:underline">View all</button>
                </div>
                {tasks.slice(0, 5).length === 0 ? (
                  <p className="text-sm text-ops-muted text-center py-4">No tasks yet</p>
                ) : (
                  <div className="space-y-2">
                    {tasks.slice(0, 5).map(task => (
                      <TaskCard key={task.id} task={task} onClick={() => router.push('/tasks')} compact />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}

          {/* ── STAFF VIEW ── */}
          {profile.role === 'staff' && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <StatCard label="Active Tasks"    value={activeTasks.length}              icon={Activity}    color="cyan"  />
                <StatCard label="Completed"       value={tasksByStatus.completed.length}  icon={CheckSquare} color="green" />
              </div>

              {/* Active Tasks */}
              {activeTasks.length > 0 && (
                <div className="bg-ops-card border border-ops-border rounded-xl p-5">
                  <h3 className="font-semibold text-ops-text flex items-center gap-2 mb-4">
                    <AlertCircle className="w-4 h-4 text-ops-amber" /> Active Tasks
                  </h3>
                  <div className="space-y-2">
                    {activeTasks.map(task => (
                      <TaskCard key={task.id} task={task} onClick={() => router.push('/tasks')} />
                    ))}
                  </div>
                </div>
              )}

              {activeTasks.length === 0 && (
                <div className="bg-ops-card border border-ops-border rounded-xl p-10 text-center">
                  <CheckSquare className="w-12 h-12 text-ops-green mx-auto mb-3" />
                  <p className="text-ops-text font-medium">All caught up!</p>
                  <p className="text-sm text-ops-muted mt-1">No active tasks assigned to you right now.</p>
                </div>
              )}

              {/* Map quick link */}
              <button
                onClick={() => router.push('/checkin')}
                className="w-full flex items-center justify-between bg-ops-cyan/10 border border-ops-cyan/30 rounded-xl p-4 hover:bg-ops-cyan/20 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-ops-cyan" />
                  <div className="text-left">
                    <div className="text-sm font-semibold text-ops-cyan">GPS Check-In</div>
                    <div className="text-xs text-ops-muted">Verify your location and update task status</div>
                  </div>
                </div>
                <div className="text-ops-cyan text-lg">→</div>
              </button>
            </>
          )}
        </div>
      )}
    </Layout>
  );
}

// src/pages/map.jsx — Operations Live Map (all tasks + GPS pins)
import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import { Layers, Building2, Package, PartyPopper, CheckCircle, Circle } from 'lucide-react';
import Layout from '../components/shared/Layout';
import { useAuth } from '../hooks/useAuth';
import { useTasks } from '../hooks/useTasks';

const OpsMap = dynamic(() => import('../components/shared/OpsMap'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full bg-ops-surface rounded-xl border border-ops-border flex items-center justify-center">
      <div className="text-ops-muted text-sm font-mono animate-pulse">Initializing map…</div>
    </div>
  ),
});

export default function MapPage() {
  const router = useRouter();
  const { profile, loading: authLoading } = useAuth();
  const { tasks, loading } = useTasks();
  const [typeFilter, setTypeFilter] = useState({ bank: true, delivery: true, party: true });
  const [statusFilter, setStatusFilter] = useState({ pending: true, assigned: true, in_progress: true, completed: false });

  useEffect(() => { if (!authLoading && !profile) router.replace('/'); }, [profile, authLoading, router]);

  const visibleTasks = tasks.filter(t =>
    typeFilter[t.type] && statusFilter[t.status]
  );

  const toggleType   = (t) => setTypeFilter(f => ({ ...f, [t]: !f[t] }));
  const toggleStatus = (s) => setStatusFilter(f => ({ ...f, [s]: !f[s] }));

  return (
    <Layout title="Operations Map">
      <div className="flex flex-col lg:flex-row gap-4 h-[calc(100vh-8rem)]">
        {/* Map */}
        <div className="flex-1 rounded-2xl overflow-hidden border border-ops-border min-h-[400px]">
          {!loading && <OpsMap tasks={visibleTasks} />}
        </div>

        {/* Sidebar controls */}
        <div className="lg:w-64 flex flex-col gap-4 lg:overflow-y-auto">
          {/* Type filters */}
          <div className="bg-ops-card border border-ops-border rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-ops-cyan" />
              <h3 className="text-sm font-semibold text-ops-text">Task Types</h3>
            </div>
            <div className="space-y-2">
              {[
                { key: 'bank',     label: 'Bank Deposits', icon: Building2,   color: 'text-ops-amber' },
                { key: 'delivery', label: 'Deliveries',    icon: Package,     color: 'text-ops-cyan'  },
                { key: 'party',    label: 'Party Visits',  icon: PartyPopper, color: 'text-purple-400'},
              ].map(({ key, label, icon: Icon, color }) => (
                <button key={key} onClick={() => toggleType(key)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors border
                    ${typeFilter[key] ? 'bg-ops-surface border-ops-border' : 'border-transparent opacity-40'}`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                  <span className="text-ops-text flex-1 text-left">{label}</span>
                  <span className="text-xs text-ops-muted font-mono">{tasks.filter(t => t.type === key).length}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Status filters */}
          <div className="bg-ops-card border border-ops-border rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Circle className="w-4 h-4 text-ops-cyan" />
              <h3 className="text-sm font-semibold text-ops-text">Status</h3>
            </div>
            <div className="space-y-2">
              {[
                { key: 'pending',     label: 'Pending',     color: 'text-ops-amber'  },
                { key: 'assigned',    label: 'Assigned',    color: 'text-ops-cyan'   },
                { key: 'in_progress', label: 'In Progress', color: 'text-purple-400' },
                { key: 'completed',   label: 'Completed',   color: 'text-ops-green'  },
              ].map(({ key, label, color }) => (
                <button key={key} onClick={() => toggleStatus(key)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors border
                    ${statusFilter[key] ? 'bg-ops-surface border-ops-border' : 'border-transparent opacity-40'}`}>
                  <CheckCircle className={`w-4 h-4 ${color}`} />
                  <span className="text-ops-text flex-1 text-left">{label}</span>
                  <span className="text-xs text-ops-muted font-mono">{tasks.filter(t => t.status === key).length}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Visible count */}
          <div className="bg-ops-card border border-ops-border rounded-xl p-4 text-center">
            <div className="text-2xl font-bold font-mono text-ops-cyan">{visibleTasks.length}</div>
            <div className="text-xs text-ops-muted">visible tasks</div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

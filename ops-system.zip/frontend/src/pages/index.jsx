// src/pages/index.jsx — Login Page
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Activity, Eye, EyeOff, Loader2, Lock, Mail } from 'lucide-react';
import { signIn } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

export default function LoginPage() {
  const router = useRouter();
  const { profile, loading } = useAuth();
  const [form, setForm]     = useState({ email: '', password: '' });
  const [show, setShow]     = useState(false);
  const [error, setError]   = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && profile) router.replace('/dashboard');
  }, [profile, loading, router]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    const { error: authError } = await signIn(form.email, form.password);
    setSubmitting(false);
    if (authError) return setError(authError.message);
    router.push('/dashboard');
  };

  if (loading) return (
    <div className="min-h-screen bg-ops-bg flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-ops-cyan animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-ops-bg flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-ops-cyan/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl" />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: 'linear-gradient(#00d4ff 1px, transparent 1px), linear-gradient(90deg, #00d4ff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
      </div>

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-ops-cyan/10 border border-ops-cyan/30 mb-4 glow-cyan">
            <Activity className="w-7 h-7 text-ops-cyan" />
          </div>
          <h1 className="text-2xl font-bold text-ops-text tracking-tight">
            OPS<span className="text-ops-cyan">SYSTEM</span>
          </h1>
          <p className="text-sm text-ops-muted mt-1 font-mono">Staff & Operations Management</p>
        </div>

        {/* Card */}
        <div className="bg-ops-surface border border-ops-border rounded-2xl p-6 shadow-2xl">
          <h2 className="text-base font-semibold text-ops-text mb-5">Sign in to your account</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-1.5 block">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ops-muted" />
                <input
                  type="email" required
                  value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                  placeholder="you@company.com"
                  className="w-full bg-ops-card border border-ops-border rounded-xl pl-10 pr-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-ops-muted uppercase tracking-wider font-medium mb-1.5 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ops-muted" />
                <input
                  type={show ? 'text' : 'password'} required
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="••••••••"
                  className="w-full bg-ops-card border border-ops-border rounded-xl pl-10 pr-10 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
                />
                <button type="button" onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-ops-muted hover:text-ops-text">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="text-xs text-ops-red bg-ops-red/10 border border-ops-red/30 rounded-lg px-3 py-2">{error}</div>
            )}

            <button
              type="submit" disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-ops-cyan text-ops-bg font-semibold text-sm hover:bg-ops-cyan-dim transition-colors flex items-center justify-center gap-2 disabled:opacity-60 mt-2"
            >
              {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Signing in…</> : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-ops-muted mt-6 font-mono">
          Contact your administrator to create an account
        </p>
      </div>
    </div>
  );
}

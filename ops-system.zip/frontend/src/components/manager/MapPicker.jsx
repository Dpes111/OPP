// src/components/manager/MapPicker.jsx — Interactive map for coordinate picking
import { useEffect, useRef } from 'react';

export default function MapPicker({ lat, lng, onPick }) {
  const mapRef    = useRef(null);
  const markerRef = useRef(null);
  const instanceRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || instanceRef.current) return;

    // Dynamically import Leaflet (browser-only)
    import('leaflet').then(L => {
      // Fix default icon paths for Next.js
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
        iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      });

      const initialLat = parseFloat(lat) || 27.7172;
      const initialLng = parseFloat(lng) || 85.3240;

      const map = L.map(mapRef.current, { zoomControl: true }).setView([initialLat, initialLng], 14);
      instanceRef.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19,
      }).addTo(map);

      // Initial marker
      const marker = L.marker([initialLat, initialLng], { draggable: true }).addTo(map);
      markerRef.current = marker;

      marker.on('dragend', () => {
        const pos = marker.getLatLng();
        onPick(pos.lat, pos.lng);
      });

      map.on('click', (e) => {
        marker.setLatLng(e.latlng);
        onPick(e.latlng.lat, e.latlng.lng);
      });
    });

    return () => {
      if (instanceRef.current) {
        instanceRef.current.remove();
        instanceRef.current = null;
      }
    };
  }, []); // eslint-disable-line

  // Update marker if lat/lng props change externally
  useEffect(() => {
    if (markerRef.current && lat && lng) {
      markerRef.current.setLatLng([parseFloat(lat), parseFloat(lng)]);
    }
  }, [lat, lng]);

  return (
    <div className="relative">
      <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      />
      <div
        ref={mapRef}
        className="w-full h-52 rounded-xl border border-ops-border overflow-hidden"
        style={{ zIndex: 1 }}
      />
      <div className="absolute bottom-2 left-2 z-10 bg-ops-bg/80 border border-ops-border rounded-lg px-2 py-1">
        <span className="text-[10px] text-ops-muted font-mono">Click or drag pin to set location</span>
      </div>
    </div>
  );
}

// src/components/manager/TaskModal.jsx — Create/view task with map picker
import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { X, MapPin, Building2, Package, PartyPopper, Calendar, User, FileText, Loader2 } from 'lucide-react';
import { createTask, updateTask } from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';

// SSR-safe Leaflet import
const MapPicker = dynamic(() => import('./MapPicker'), { ssr: false, loading: () => (
  <div className="h-48 bg-ops-surface rounded-xl border border-ops-border flex items-center justify-center">
    <Loader2 className="w-5 h-5 text-ops-cyan animate-spin" />
  </div>
)});

const TYPES = [
  { value: 'bank',     label: 'Bank Deposit', icon: Building2,   color: 'text-ops-amber',  border: 'border-ops-amber/40',  bg: 'bg-ops-amber/10'  },
  { value: 'delivery', label: 'Delivery',     icon: Package,     color: 'text-ops-cyan',   border: 'border-ops-cyan/40',   bg: 'bg-ops-cyan/10'   },
  { value: 'party',    label: 'Party Visit',  icon: PartyPopper, color: 'text-purple-400', border: 'border-purple-400/40', bg: 'bg-purple-500/10' },
];

export default function TaskModal({ task, onClose, onSaved }) {
  const { token } = useAuth();
  const isEdit = !!task;
  const [staff, setStaff]     = useState([]);
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState('');
  const [form, setForm] = useState({
    title: task?.title || '',
    type: task?.type || 'delivery',
    description: task?.description || '',
    location_name: task?.location_name || '',
    latitude: task?.latitude || '',
    longitude: task?.longitude || '',
    assigned_to: task?.assigned_to || '',
    due_date: task?.due_date ? task.due_date.slice(0, 16) : '',
  });

  useEffect(() => {
    supabase.from('profiles').select('id, full_name').eq('role', 'staff').eq('is_active', true)
      .then(({ data }) => setStaff(data || []));
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.location_name || !form.latitude || !form.longitude) {
      return setError('Title, location name, and map pin are required.');
    }
    setSaving(true);
    setError('');
    try {
      if (isEdit) {
        await updateTask(task.id, form, token);
      } else {
        await createTask(form, token);
      }
      onSaved?.();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-ops-surface border border-ops-border rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-ops-border sticky top-0 bg-ops-surface z-10">
          <h2 className="font-bold text-ops-text">{isEdit ? 'Edit Task' : 'Assign New Task'}</h2>
          <button onClick={onClose} className="text-ops-muted hover:text-ops-text transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Task Type */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-2 block">Task Type</label>
            <div className="grid grid-cols-3 gap-2">
              {TYPES.map(({ value, label, icon: Icon, color, border, bg }) => (
                <button
                  key={value} type="button"
                  onClick={() => set('type', value)}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center
                    ${form.type === value ? `${bg} ${border}` : 'border-ops-border bg-ops-card hover:border-ops-muted'}`}
                >
                  <Icon className={`w-5 h-5 ${form.type === value ? color : 'text-ops-muted'}`} />
                  <span className={`text-xs font-medium ${form.type === value ? color : 'text-ops-muted'}`}>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">Task Title *</label>
            <input
              value={form.title}
              onChange={e => set('title', e.target.value)}
              placeholder="e.g. Daily Cash Deposit — Branch A"
              className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">
              <FileText className="w-3 h-3 inline mr-1" />Description
            </label>
            <textarea
              value={form.description}
              onChange={e => set('description', e.target.value)}
              rows={2}
              placeholder="Additional instructions..."
              className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan resize-none"
            />
          </div>

          {/* Location Name */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">
              <MapPin className="w-3 h-3 inline mr-1" />Location Name *
            </label>
            <input
              value={form.location_name}
              onChange={e => set('location_name', e.target.value)}
              placeholder="e.g. Nepal Investment Bank, Kathmandu"
              className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
            />
          </div>

          {/* Map Picker */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">
              Pin Location on Map * {form.latitude && form.longitude && (
                <span className="text-ops-green ml-1">({parseFloat(form.latitude).toFixed(4)}, {parseFloat(form.longitude).toFixed(4)})</span>
              )}
            </label>
            <MapPicker
              lat={form.latitude || 27.7172}
              lng={form.longitude || 85.3240}
              onPick={(lat, lng) => { set('latitude', lat); set('longitude', lng); }}
            />
          </div>

          {/* Assign To */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">
              <User className="w-3 h-3 inline mr-1" />Assign to Staff
            </label>
            <select
              value={form.assigned_to}
              onChange={e => set('assigned_to', e.target.value)}
              className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text focus:outline-none focus:border-ops-cyan"
            >
              <option value="">— Unassigned —</option>
              {staff.map(s => <option key={s.id} value={s.id}>{s.full_name}</option>)}
            </select>
          </div>

          {/* Due Date */}
          <div>
            <label className="text-xs font-medium text-ops-muted uppercase tracking-wider mb-1.5 block">
              <Calendar className="w-3 h-3 inline mr-1" />Due Date
            </label>
            <input
              type="datetime-local"
              value={form.due_date}
              onChange={e => set('due_date', e.target.value)}
              className="w-full bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text focus:outline-none focus:border-ops-cyan"
            />
          </div>

          {error && (
            <div className="text-xs text-ops-red bg-ops-red/10 border border-ops-red/30 rounded-lg px-3 py-2">{error}</div>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button" onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl border border-ops-border text-ops-muted hover:text-ops-text text-sm font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit" disabled={saving}
              className="flex-1 px-4 py-2.5 rounded-xl bg-ops-cyan text-ops-bg font-semibold text-sm hover:bg-ops-cyan-dim transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</> : isEdit ? 'Update Task' : 'Assign Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// src/components/shared/OpsMap.jsx — Full operations map with task markers
import { useEffect, useRef } from 'react';

const TYPE_COLORS = { bank: '#f59e0b', delivery: '#00d4ff', party: '#8b5cf6' };
const STATUS_OPACITY = { pending: 0.5, assigned: 0.85, in_progress: 1, completed: 0.4, cancelled: 0.2 };

export default function OpsMap({ tasks = [] }) {
  const mapRef      = useRef(null);
  const instanceRef = useRef(null);
  const markersRef  = useRef([]);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || instanceRef.current) return;

    import('leaflet').then(L => {
      const map = L.map(mapRef.current, { zoomControl: true }).setView([27.7172, 85.3240], 12);
      instanceRef.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
    });

    return () => { if (instanceRef.current) { instanceRef.current.remove(); instanceRef.current = null; } };
  }, []);

  // Update markers when tasks change
  useEffect(() => {
    if (!instanceRef.current || typeof window === 'undefined') return;

    import('leaflet').then(L => {
      // Remove old markers
      markersRef.current.forEach(m => m.remove());
      markersRef.current = [];

      if (tasks.length === 0) return;

      const bounds = [];
      tasks.forEach(task => {
        if (!task.latitude || !task.longitude) return;
        const color   = TYPE_COLORS[task.type] || '#00d4ff';
        const opacity = STATUS_OPACITY[task.status] || 0.7;
        const typeEmoji = { bank: '🏦', delivery: '📦', party: '🎉' }[task.type] || '📍';

        const icon = L.divIcon({
          html: `
            <div style="
              position: relative;
              width: 36px; height: 36px;
              background: ${color}22;
              border: 2px solid ${color};
              border-radius: 50% 50% 50% 0;
              transform: rotate(-45deg);
              opacity: ${opacity};
              box-shadow: 0 0 12px ${color}66;
            ">
              <div style="
                position: absolute; inset: 0;
                display: flex; align-items: center; justify-content: center;
                transform: rotate(45deg);
                font-size: 14px;
              ">${typeEmoji}</div>
            </div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 36],
          className: '',
        });

        const assigneeName = task.assigned_to_profile?.full_name || 'Unassigned';
        const popup = L.popup({ className: 'ops-popup' }).setContent(`
          <div style="font-family: 'IBM Plex Sans', sans-serif; min-width: 180px; padding: 4px;">
            <div style="font-weight: 700; color: ${color}; margin-bottom: 4px;">${task.title}</div>
            <div style="font-size: 11px; color: #94a3b8; margin-bottom: 6px;">${task.location_name}</div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <span style="font-size: 10px; background: ${color}22; color: ${color}; border: 1px solid ${color}44; padding: 2px 6px; border-radius: 20px; font-family: monospace;">
                ${task.status.replace('_', ' ').toUpperCase()}
              </span>
              <span style="font-size: 10px; color: #64748b;">${assigneeName}</span>
            </div>
            ${task.due_date ? `<div style="font-size: 10px; color: #64748b; margin-top: 4px;">Due: ${new Date(task.due_date).toLocaleDateString()}</div>` : ''}
          </div>
        `);

        const marker = L.marker([task.latitude, task.longitude], { icon }).addTo(instanceRef.current).bindPopup(popup);
        markersRef.current.push(marker);
        bounds.push([task.latitude, task.longitude]);
      });

      if (bounds.length > 0) {
        instanceRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
      }
    });
  }, [tasks]);

  return (
    <>
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      <div ref={mapRef} className="w-full h-full" style={{ minHeight: '400px' }} />
    </>
  );
}

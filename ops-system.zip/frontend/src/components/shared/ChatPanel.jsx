// src/components/shared/ChatPanel.jsx — Hub-and-spoke messaging UI
import { useState, useEffect, useRef } from 'react';
import { Send, MessageSquare, Lock } from 'lucide-react';
import { useChat } from '../../hooks/useChat';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';

export default function ChatPanel({ partnerId, partnerName }) {
  const { profile } = useAuth();
  const { messages, loading, sending, sendMessage } = useChat(partnerId);
  const [text, setText] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendMessage(text.trim());
    setText('');
  };

  if (!partnerId) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3 text-center">
        <MessageSquare className="w-10 h-10 text-ops-border" />
        <p className="text-ops-muted text-sm">Select a conversation to start messaging</p>
        {profile?.role === 'staff' && (
          <div className="flex items-center gap-1.5 text-xs text-ops-amber bg-ops-amber/10 border border-ops-amber/30 rounded-lg px-3 py-1.5">
            <Lock className="w-3 h-3" />
            Staff-to-staff messaging is disabled for focus
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-ops-border flex items-center gap-3 flex-shrink-0">
        <div className="w-8 h-8 rounded-lg bg-ops-border flex items-center justify-center">
          <span className="text-sm font-bold text-ops-text">{partnerName?.charAt(0)}</span>
        </div>
        <div>
          <div className="text-sm font-semibold text-ops-text">{partnerName}</div>
          <div className="text-[10px] text-ops-green">● Active</div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 chat-scroll">
        {loading && (
          <div className="text-center text-xs text-ops-muted py-4">Loading messages…</div>
        )}
        {!loading && messages.length === 0 && (
          <div className="text-center text-xs text-ops-muted py-8">
            No messages yet. Say hello! 👋
          </div>
        )}
        {messages.map((msg) => {
          const isOwn = msg.sender_id === profile?.id;
          return (
            <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
              <div className={`
                max-w-[75%] px-3 py-2 rounded-2xl text-sm
                ${isOwn
                  ? 'bg-ops-cyan text-ops-bg rounded-br-sm font-medium'
                  : 'bg-ops-card border border-ops-border text-ops-text rounded-bl-sm'}
              `}>
                <p>{msg.content}</p>
                <p className={`text-[10px] mt-1 ${isOwn ? 'text-ops-bg/60' : 'text-ops-muted'} text-right`}>
                  {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-3 border-t border-ops-border flex gap-2 flex-shrink-0">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={`Message ${partnerName}…`}
          className="flex-1 bg-ops-card border border-ops-border rounded-xl px-4 py-2.5 text-sm text-ops-text placeholder-ops-muted focus:outline-none focus:border-ops-cyan"
        />
        <button
          type="submit" disabled={!text.trim() || sending}
          className="w-10 h-10 rounded-xl bg-ops-cyan hover:bg-ops-cyan-dim transition-colors flex items-center justify-center disabled:opacity-40"
        >
          <Send className="w-4 h-4 text-ops-bg" />
        </button>
      </form>
    </div>
  );
}

// Conversation list sidebar
export function ConversationList({ selectedId, onSelect }) {
  const { profile } = useAuth();
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    if (!profile) return;
    let query = supabase.from('profiles').select('id, full_name, role').eq('is_active', true);

    if (profile.role === 'staff') {
      // Staff can only message managers and admins
      query = query.in('role', ['manager', 'admin']);
    } else {
      // Managers/admins can message anyone except themselves
      query = query.neq('id', profile.id);
    }

    query.then(({ data }) => setContacts(data || []));
  }, [profile]);

  const ROLE_COLOR = { admin: 'text-ops-red', manager: 'text-ops-amber', staff: 'text-ops-cyan' };

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-ops-border">
        <h2 className="text-sm font-bold text-ops-text">Conversations</h2>
        {profile?.role === 'staff' && (
          <div className="flex items-center gap-1 mt-1 text-[10px] text-ops-muted">
            <Lock className="w-3 h-3" />Managers & Admins only
          </div>
        )}
      </div>
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {contacts.map(c => (
          <button
            key={c.id}
            onClick={() => onSelect(c.id, c.full_name)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors
              ${selectedId === c.id ? 'bg-ops-cyan/10 border border-ops-cyan/30' : 'hover:bg-ops-card border border-transparent'}`}
          >
            <div className="w-8 h-8 rounded-lg bg-ops-border flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-bold text-ops-text">{c.full_name?.charAt(0)}</span>
            </div>
            <div>
              <div className="text-sm font-medium text-ops-text">{c.full_name}</div>
              <div className={`text-[10px] font-mono uppercase ${ROLE_COLOR[c.role]}`}>{c.role}</div>
            </div>
          </button>
        ))}
        {contacts.length === 0 && (
          <div className="text-center text-xs text-ops-muted py-8">No contacts available</div>
        )}
      </div>
    </div>
  );
}

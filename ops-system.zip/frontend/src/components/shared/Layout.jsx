// src/components/shared/Layout.jsx — Main app shell with sidebar navigation
import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import {
  LayoutDashboard, CheckSquare, MessageSquare, Users,
  MapPin, ClipboardList, Settings, LogOut, Menu, X,
  Bell, ChevronRight, Activity, Shield
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useUnreadCounts } from '../../hooks/useChat';

const NAV_ITEMS = {
  admin: [
    { href: '/dashboard', label: 'Dashboard',  icon: LayoutDashboard },
    { href: '/tasks',     label: 'Tasks',       icon: CheckSquare },
    { href: '/users',     label: 'Users',       icon: Users },
    { href: '/map',       label: 'Live Map',    icon: MapPin },
    { href: '/logs',      label: 'Audit Logs',  icon: ClipboardList },
    { href: '/chat',      label: 'Messages',    icon: MessageSquare },
  ],
  manager: [
    { href: '/dashboard', label: 'Dashboard',   icon: LayoutDashboard },
    { href: '/tasks',     label: 'Tasks',        icon: CheckSquare },
    { href: '/staff',     label: 'Staff',        icon: Users },
    { href: '/map',       label: 'Live Map',     icon: MapPin },
    { href: '/logs',      label: 'Logs',         icon: Activity },
    { href: '/chat',      label: 'Messages',     icon: MessageSquare },
  ],
  staff: [
    { href: '/dashboard', label: 'My Tasks',    icon: CheckSquare },
    { href: '/map',       label: 'Map',         icon: MapPin },
    { href: '/checkin',   label: 'Check-In',    icon: MapPin },
    { href: '/chat',      label: 'Messages',    icon: MessageSquare },
  ],
};

const ROLE_COLORS = { admin: 'text-ops-red', manager: 'text-ops-amber', staff: 'text-ops-cyan' };
const ROLE_ICONS  = { admin: Shield, manager: Activity, staff: Users };

export default function Layout({ children, title }) {
  const { profile, signOut } = useAuth();
  const router = useRouter();
  const unread = useUnreadCounts();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const totalUnread = Object.values(unread).reduce((a, b) => a + b, 0);
  const navItems = NAV_ITEMS[profile?.role] || [];
  const RoleIcon = ROLE_ICONS[profile?.role] || Users;

  return (
    <div className="flex h-screen bg-ops-bg overflow-hidden">
      {/* ── Sidebar ───────────────────────────────────────── */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-ops-surface border-r border-ops-border
        flex flex-col transform transition-transform duration-300 ease-in-out
        lg:static lg:translate-x-0
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-ops-border">
          <div className="w-8 h-8 rounded-lg bg-ops-cyan/20 border border-ops-cyan/40 flex items-center justify-center">
            <Activity className="w-4 h-4 text-ops-cyan" />
          </div>
          <div>
            <div className="text-sm font-bold text-ops-text tracking-wider">OPS<span className="text-ops-cyan">SYSTEM</span></div>
            <div className="text-[10px] text-ops-muted font-mono uppercase tracking-widest">Operations Hub</div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden text-ops-muted hover:text-ops-text">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile pill */}
        <div className="mx-4 mt-4 mb-2 p-3 rounded-xl bg-ops-card border border-ops-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-ops-cyan/30 to-ops-purple/30 border border-ops-border flex items-center justify-center">
              <span className="text-sm font-bold text-ops-text">
                {profile?.full_name?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-ops-text truncate">{profile?.full_name}</div>
              <div className={`text-[11px] font-mono uppercase tracking-widest ${ROLE_COLORS[profile?.role]}`}>
                {profile?.role}
              </div>
            </div>
            <RoleIcon className={`w-4 h-4 ${ROLE_COLORS[profile?.role]}`} />
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          {navItems.map(({ href, label, icon: Icon }) => {
            const isActive = router.pathname === href;
            const badge = href === '/chat' && totalUnread > 0 ? totalUnread : null;
            return (
              <Link key={href} href={href} onClick={() => setSidebarOpen(false)}>
                <div className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer
                  transition-all duration-150 group relative
                  ${isActive
                    ? 'bg-ops-cyan/10 border border-ops-cyan/30 text-ops-cyan'
                    : 'text-ops-muted hover:text-ops-text hover:bg-ops-card border border-transparent'}
                `}>
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-ops-cyan' : 'group-hover:text-ops-text'}`} />
                  <span className="text-sm font-medium">{label}</span>
                  {badge && (
                    <span className="ml-auto text-[10px] bg-ops-red text-white font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                      {badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-3 h-3 ml-auto" />}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Sign out */}
        <div className="p-4 border-t border-ops-border">
          <button
            onClick={signOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-ops-muted hover:text-ops-red hover:bg-ops-red/10 transition-all text-sm font-medium"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* ── Main Content ──────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-14 bg-ops-surface border-b border-ops-border flex items-center px-4 lg:px-6 gap-4 flex-shrink-0">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-ops-muted hover:text-ops-text">
            <Menu className="w-5 h-5" />
          </button>
          <h1 className="text-base font-semibold text-ops-text">{title}</h1>
          <div className="ml-auto flex items-center gap-3">
            {totalUnread > 0 && (
              <Link href="/chat">
                <div className="relative">
                  <Bell className="w-5 h-5 text-ops-muted hover:text-ops-text cursor-pointer" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-ops-red text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {totalUnread}
                  </span>
                </div>
              </Link>
            )}
            <div className="w-px h-5 bg-ops-border" />
            <div className="text-xs text-ops-muted font-mono">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

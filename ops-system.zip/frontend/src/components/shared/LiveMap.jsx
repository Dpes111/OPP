// src/components/shared/LiveMap.jsx — Shows user + task location on map
import { useEffect, useRef } from 'react';

export default function LiveMap({ userLat, userLng, taskLat, taskLng, taskLabel }) {
  const mapRef = useRef(null);
  const instanceRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || instanceRef.current) return;

    import('leaflet').then(L => {
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
        iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      });

      const map = L.map(mapRef.current).setView([userLat, userLng], 15);
      instanceRef.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

      // User marker (blue)
      const userIcon = L.divIcon({
        html: `<div style="width:14px;height:14px;background:#00d4ff;border:3px solid white;border-radius:50%;box-shadow:0 0 10px rgba(0,212,255,0.8)"></div>`,
        iconSize: [14, 14], iconAnchor: [7, 7], className: '',
      });
      L.marker([userLat, userLng], { icon: userIcon })
        .addTo(map)
        .bindPopup('<b>You are here</b>');

      // Task marker + 100m circle
      if (taskLat && taskLng) {
        const taskIcon = L.divIcon({
          html: `<div style="width:16px;height:16px;background:#f59e0b;border:3px solid white;border-radius:4px;box-shadow:0 0 10px rgba(245,158,11,0.8)"></div>`,
          iconSize: [16, 16], iconAnchor: [8, 8], className: '',
        });
        L.marker([taskLat, taskLng], { icon: taskIcon })
          .addTo(map)
          .bindPopup(`<b>${taskLabel || 'Task Location'}</b>`);

        // 100m geofence circle
        L.circle([taskLat, taskLng], {
          radius: 100, color: '#f59e0b', fillColor: '#f59e0b',
          fillOpacity: 0.08, weight: 1.5, dashArray: '6,4',
        }).addTo(map);

        // Fit bounds to show both markers
        const bounds = L.latLngBounds([[userLat, userLng], [taskLat, taskLng]]);
        map.fitBounds(bounds, { padding: [40, 40] });
      }
    });

    return () => { if (instanceRef.current) { instanceRef.current.remove(); instanceRef.current = null; } };
  }, []); // eslint-disable-line

  return (
    <>
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      <div ref={mapRef} className="w-full h-52 rounded-xl border border-ops-border overflow-hidden" style={{ zIndex: 1 }} />
      {taskLat && (
        <div className="flex items-center gap-4 text-[11px] text-ops-muted mt-1">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-ops-cyan inline-block" /> You</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-ops-amber inline-block" /> Task location</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full border border-ops-amber inline-block" /> 100m fence</span>
        </div>
      )}
    </>
  );
}

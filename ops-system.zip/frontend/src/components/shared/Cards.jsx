// src/components/shared/Cards.jsx — Reusable card components
import { Building2, Package, PartyPopper, Clock, MapPin, User, CheckCircle2, Circle, Loader2 } from 'lucide-react';

const TASK_TYPE_CONFIG = {
  bank:     { icon: Building2,    color: 'text-ops-amber',  bg: 'bg-ops-amber/10',  border: 'border-ops-amber/30',  label: 'Bank Deposit' },
  delivery: { icon: Package,      color: 'text-ops-cyan',   bg: 'bg-ops-cyan/10',   border: 'border-ops-cyan/30',   label: 'Delivery' },
  party:    { icon: PartyPopper,  color: 'text-ops-purple', bg: 'bg-purple-500/10', border: 'border-purple-500/30', label: 'Party Visit' },
};

const STATUS_CONFIG = {
  pending:     { label: 'Pending',     class: 'badge-pending' },
  assigned:    { label: 'Assigned',    class: 'badge-assigned' },
  in_progress: { label: 'In Progress', class: 'badge-in_progress' },
  completed:   { label: 'Completed',   class: 'badge-completed' },
  cancelled:   { label: 'Cancelled',   class: 'badge-cancelled' },
};

export function TaskCard({ task, onClick, compact = false }) {
  const type   = TASK_TYPE_CONFIG[task.type] || TASK_TYPE_CONFIG.delivery;
  const status = STATUS_CONFIG[task.status]  || STATUS_CONFIG.pending;
  const TypeIcon = type.icon;

  return (
    <div
      onClick={onClick}
      className={`
        bg-ops-card border border-ops-border rounded-xl p-4 cursor-pointer
        hover:border-ops-cyan/40 hover:bg-ops-card/80 transition-all duration-200
        ${compact ? 'p-3' : 'p-4'}
      `}
    >
      <div className="flex items-start gap-3">
        <div className={`w-9 h-9 rounded-lg ${type.bg} border ${type.border} flex items-center justify-center flex-shrink-0`}>
          <TypeIcon className={`w-4 h-4 ${type.color}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-ops-text truncate">{task.title}</span>
            <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full ${status.class}`}>
              {status.label}
            </span>
          </div>
          <div className="flex items-center gap-1 mt-1">
            <MapPin className="w-3 h-3 text-ops-muted flex-shrink-0" />
            <span className="text-xs text-ops-muted truncate">{task.location_name}</span>
          </div>
          {!compact && (
            <div className="flex items-center gap-4 mt-2">
              {task.assigned_to_profile && (
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3 text-ops-muted" />
                  <span className="text-xs text-ops-muted">{task.assigned_to_profile.full_name}</span>
                </div>
              )}
              {task.due_date && (
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-ops-muted" />
                  <span className="text-xs text-ops-muted">
                    {new Date(task.due_date).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function StatCard({ label, value, icon: Icon, color = 'cyan', trend, sublabel }) {
  const colorMap = {
    cyan:   { text: 'text-ops-cyan',   bg: 'bg-ops-cyan/10',   border: 'border-ops-cyan/20'   },
    amber:  { text: 'text-ops-amber',  bg: 'bg-ops-amber/10',  border: 'border-ops-amber/20'  },
    green:  { text: 'text-ops-green',  bg: 'bg-ops-green/10',  border: 'border-ops-green/20'  },
    red:    { text: 'text-ops-red',    bg: 'bg-ops-red/10',    border: 'border-ops-red/20'    },
    purple: { text: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  };
  const c = colorMap[color] || colorMap.cyan;

  return (
    <div className={`bg-ops-card border ${c.border} rounded-xl p-5 relative overflow-hidden`}>
      <div className={`absolute top-0 right-0 w-20 h-20 ${c.bg} rounded-full -translate-y-1/2 translate-x-1/2 blur-xl`} />
      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-ops-muted font-medium uppercase tracking-wider">{label}</span>
          {Icon && (
            <div className={`w-8 h-8 ${c.bg} border ${c.border} rounded-lg flex items-center justify-center`}>
              <Icon className={`w-4 h-4 ${c.text}`} />
            </div>
          )}
        </div>
        <div className={`text-3xl font-bold font-mono ${c.text}`}>{value}</div>
        {sublabel && <div className="text-xs text-ops-muted mt-1">{sublabel}</div>}
        {trend && (
          <div className="text-xs text-ops-muted mt-2 flex items-center gap-1">
            {trend}
          </div>
        )}
      </div>
    </div>
  );
}

export function WorkloadBadge({ name, count }) {
  const color = count === 0 ? 'text-ops-green' : count <= 2 ? 'text-ops-cyan' : count <= 4 ? 'text-ops-amber' : 'text-ops-red';
  return (
    <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-ops-surface border border-ops-border">
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-md bg-ops-border flex items-center justify-center">
          <span className="text-[10px] font-bold text-ops-text">{name?.charAt(0)}</span>
        </div>
        <span className="text-sm text-ops-text font-medium">{name}</span>
      </div>
      <div className={`flex items-center gap-1 font-mono text-xs font-bold ${color}`}>
        {count === 0 ? <CheckCircle2 className="w-3 h-3" /> : <Circle className="w-3 h-3" />}
        {count} {count === 1 ? 'Task' : 'Tasks'}
      </div>
    </div>
  );
}

export function LoadingSpinner({ text = 'Loading...' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16">
      <Loader2 className="w-8 h-8 text-ops-cyan animate-spin" />
      <span className="text-sm text-ops-muted font-mono">{text}</span>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      {Icon && <Icon className="w-10 h-10 text-ops-border" />}
      <div>
        <p className="text-ops-text font-medium">{title}</p>
        {description && <p className="text-sm text-ops-muted mt-1">{description}</p>}
      </div>
      {action}
    </div>
  );
}

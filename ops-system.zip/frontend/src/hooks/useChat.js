// src/hooks/useChat.js — Realtime messaging via Supabase
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export function useChat(partnerId) {
  const { profile } = useAuth();
  const [messages, setMessages]   = useState([]);
  const [loading, setLoading]     = useState(false);
  const [sending, setSending]     = useState(false);

  const fetchMessages = useCallback(async () => {
    if (!profile?.id || !partnerId) return;
    setLoading(true);
    const { data } = await supabase
      .from('messages')
      .select(`*, sender:profiles!messages_sender_id_fkey(id, full_name, role)`)
      .or(`and(sender_id.eq.${profile.id},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${profile.id})`)
      .order('created_at', { ascending: true })
      .limit(100);
    setMessages(data || []);
    setLoading(false);

    // Mark as read
    await supabase.from('messages')
      .update({ is_read: true })
      .eq('receiver_id', profile.id)
      .eq('sender_id', partnerId);
  }, [profile?.id, partnerId]);

  useEffect(() => {
    fetchMessages();
    if (!profile?.id || !partnerId) return;

    const channel = supabase.channel(`chat:${[profile.id, partnerId].sort().join(':')}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `receiver_id=eq.${profile.id}`,
      }, (payload) => {
        if (payload.new.sender_id === partnerId) {
          setMessages(prev => [...prev, payload.new]);
        }
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [fetchMessages, profile?.id, partnerId]);

  const sendMessage = useCallback(async (content) => {
    if (!content.trim() || !partnerId || !profile?.id) return;
    setSending(true);
    const optimistic = {
      id: `opt-${Date.now()}`, sender_id: profile.id,
      receiver_id: partnerId, content, created_at: new Date().toISOString(),
      sender: { id: profile.id, full_name: profile.full_name, role: profile.role },
    };
    setMessages(prev => [...prev, optimistic]);

    const { error } = await supabase.from('messages').insert({
      sender_id: profile.id, receiver_id: partnerId, content,
    });
    if (error) {
      setMessages(prev => prev.filter(m => m.id !== optimistic.id));
      console.error('Send error:', error.message);
    }
    setSending(false);
  }, [profile, partnerId]);

  return { messages, loading, sending, sendMessage };
}

// Get unread counts per conversation partner
export function useUnreadCounts() {
  const { profile } = useAuth();
  const [counts, setCounts] = useState({});

  useEffect(() => {
    if (!profile?.id) return;
    const fetch = async () => {
      const { data } = await supabase.from('messages')
        .select('sender_id')
        .eq('receiver_id', profile.id)
        .eq('is_read', false);
      const c = {};
      for (const m of (data || [])) c[m.sender_id] = (c[m.sender_id] || 0) + 1;
      setCounts(c);
    };
    fetch();
    const ch = supabase.channel('unread:' + profile.id)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `receiver_id=eq.${profile.id}` }, fetch)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [profile?.id]);

  return counts;
}

// src/hooks/useAuth.js — Auth state + profile management
import { useState, useEffect, useContext, createContext, useCallback } from 'react';
import { supabase, getProfile } from '../lib/supabase';
import { registerPushSubscription } from '../lib/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [profile, setProfile] = useState(null);
  const [token, setToken]     = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (session) => {
    if (!session) { setUser(null); setProfile(null); setToken(null); return; }
    setUser(session.user);
    setToken(session.access_token);
    const { data } = await getProfile(session.user.id);
    setProfile(data);
    // Register push subscription on login
    if (data) {
      await registerPushSubscription(session.access_token);
    }
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      loadProfile(session).finally(() => setLoading(false));
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      loadProfile(session);
    });
    return () => subscription.unsubscribe();
  }, [loadProfile]);

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null); setProfile(null); setToken(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, token, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

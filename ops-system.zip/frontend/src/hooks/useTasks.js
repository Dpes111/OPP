// src/hooks/useTasks.js — Live task data with Supabase Realtime
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import { getTasks, getStaffWorkload } from '../lib/api';

export function useTasks() {
  const { token, profile } = useAuth();
  const [tasks, setTasks]       = useState([]);
  const [workload, setWorkload] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);

  const fetchAll = useCallback(async () => {
    if (!token) return;
    try {
      setLoading(true);
      const [tasksData, workloadData] = await Promise.all([
        getTasks(token),
        profile?.role !== 'staff' ? getStaffWorkload(token) : Promise.resolve({ workload: [] }),
      ]);
      setTasks(tasksData.tasks || []);
      setWorkload(workloadData.workload || []);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [token, profile?.role]);

  useEffect(() => {
    fetchAll();
    if (!profile?.id) return;

    const channel = supabase.channel('tasks:live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, () => {
        fetchAll();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [fetchAll, profile?.id]);

  const tasksByStatus = {
    pending:     tasks.filter(t => t.status === 'pending'),
    assigned:    tasks.filter(t => t.status === 'assigned'),
    in_progress: tasks.filter(t => t.status === 'in_progress'),
    completed:   tasks.filter(t => t.status === 'completed'),
    cancelled:   tasks.filter(t => t.status === 'cancelled'),
  };

  const activeTasks = tasks.filter(t => ['assigned', 'in_progress'].includes(t.status));

  return { tasks, tasksByStatus, activeTasks, workload, loading, error, refetch: fetchAll };
}

# 🏢 OpsSystem — Staff & Operations Management System

A professional, full-stack operations management platform for managing physical tasks (Bank Deposits, Deliveries, Party Visits) with GPS geofencing, real-time push notifications, and role-based access control.

---

## ✨ Feature Overview

| Feature | Details |
|---|---|
| **RBAC** | Admin / Manager / Staff with Supabase RLS |
| **Task System** | Bank · Delivery · Party with GPS coordinates |
| **Geofencing** | Haversine formula — 100m check-in validation |
| **Push Notifications** | Web Push API with VAPID (no Firebase) |
| **Real-time Chat** | Hub-and-spoke: Staff ↔ Manager/Admin only |
| **Live Map** | Leaflet.js + OpenStreetMap (free tier) |
| **PWA** | Service Worker + manifest.json — installable |
| **Dark UI** | Professional dark theme with Tailwind CSS |

---

## 🗂 Project Structure

```
ops-system/
├── supabase/
│   └── schema.sql            # Full DB schema + RLS policies
├── backend/                  # Node.js + Express API
│   ├── server.js
│   ├── lib/
│   │   ├── supabase.js       # Auth middleware
│   │   ├── geofence.js       # Haversine formula
│   │   └── pushService.js    # Web Push / VAPID
│   ├── routes/
│   │   ├── tasks.js
│   │   ├── attendance.js
│   │   ├── notifications.js
│   │   └── auth.js
│   └── scripts/
│       └── generate-vapid.js
└── frontend/                 # Next.js + Tailwind
    ├── public/
    │   ├── sw.js             # Service Worker (PWA + Push)
    │   └── manifest.json     # PWA manifest
    └── src/
        ├── pages/            # dashboard, tasks, chat, map, checkin, logs, users
        ├── components/
        │   ├── shared/       # Layout, Cards, ChatPanel, LiveMap, OpsMap
        │   └── manager/      # TaskModal, MapPicker
        ├── hooks/            # useAuth, useTasks, useChat
        └── lib/              # supabase.js, api.js
```

---

## 🚀 Setup Guide

### Step 1 — Supabase Project

1. Go to [supabase.com](https://supabase.com) → **New Project**
2. Open **SQL Editor** → paste the entire contents of `supabase/schema.sql` → **Run**
3. Go to **Authentication → Settings** → disable email confirmation (for dev)
4. Note your **Project URL** and **anon key** (Settings → API)
5. Note your **service_role key** (for the backend — keep secret!)

**Create your first Admin user:**
```sql
-- After creating user in Supabase Auth dashboard:
UPDATE profiles SET role = 'admin' WHERE email = 'admin@yourcompany.com';
```

### Step 2 — Backend Setup

```bash
cd backend
cp .env.example .env
npm install

# Generate VAPID keys for push notifications
node scripts/generate-vapid.js
# → Copy the output into your .env file

# Fill in .env:
# SUPABASE_URL=...
# SUPABASE_SERVICE_ROLE_KEY=...
# VAPID_PUBLIC_KEY=...
# VAPID_PRIVATE_KEY=...
# VAPID_EMAIL=your@email.com
# FRONTEND_URL=http://localhost:3000

npm run dev
# API running at http://localhost:4000
```

### Step 3 — Frontend Setup

```bash
cd frontend
cp .env.local.example .env.local
npm install

# Fill in .env.local:
# NEXT_PUBLIC_SUPABASE_URL=...
# NEXT_PUBLIC_SUPABASE_ANON_KEY=...
# NEXT_PUBLIC_API_URL=http://localhost:4000/api

npm run dev
# App running at http://localhost:3000
```

### Step 4 — PWA Icons

Place the following icon files in `frontend/public/icons/`:
- `icon-72.png`, `icon-96.png`, `icon-128.png`
- `icon-192.png` ← required for PWA install
- `icon-512.png` ← required for splash screen
- `badge-72.png` ← for push notification badge

> Use [realfavicongenerator.net](https://realfavicongenerator.net) to generate from a single 512×512 source image.

---

## 🔐 Role Permissions Matrix

| Action | Admin | Manager | Staff |
|---|:---:|:---:|:---:|
| Create/delete users | ✅ | ❌ | ❌ |
| Assign tasks | ✅ | ✅ | ❌ |
| View all tasks | ✅ | ✅ | ❌ |
| View own tasks | ✅ | ✅ | ✅ |
| GPS check-in | ✅ | ✅ | ✅ |
| Complete tasks | ✅ | ✅ | ✅* |
| Message managers | ✅ | ✅ | ✅ |
| Message staff | ✅ | ✅ | ❌ |
| View attendance logs | ✅ | ✅ | Own only |

*Staff must be within 100m of task location to complete

---

## 📡 API Reference

### Tasks
| Method | Endpoint | Role | Description |
|---|---|---|---|
| GET | `/api/tasks` | All | List tasks (RLS filtered) |
| GET | `/api/tasks/staff-workload` | Admin/Manager | Active count per staff |
| POST | `/api/tasks` | Admin/Manager | Create + assign task |
| PATCH | `/api/tasks/:id` | All | Update task |
| DELETE | `/api/tasks/:id` | Admin/Manager | Delete task |

### Attendance
| Method | Endpoint | Role | Description |
|---|---|---|---|
| POST | `/api/attendance/checkin` | All | Log GPS check-in |
| POST | `/api/attendance/complete` | Staff | Complete task (geofenced) |
| GET | `/api/attendance` | All | View logs (RLS filtered) |

### Notifications
| Method | Endpoint | Role | Description |
|---|---|---|---|
| GET | `/api/notifications/vapid-public-key` | Public | Get VAPID public key |
| POST | `/api/notifications/subscribe` | Auth | Save push subscription |
| POST | `/api/notifications/test` | Auth | Send test notification |

---

## 🌐 Deployment

### Frontend → Vercel
```bash
cd frontend
npx vercel --prod
# Set environment variables in Vercel dashboard
```

### Backend → Railway / Render (free tier)
```bash
# railway.app or render.com
# Connect GitHub repo, set environment variables
# Auto-deploys on push
```

### Supabase
- Database and Auth are already hosted on Supabase free tier
- Enable Realtime for `tasks`, `messages`, `attendance_logs` tables

---

## 🔧 Key Technical Decisions

**Haversine Geofencing (backend/lib/geofence.js)**
```js
// Pure math — no API cost, works server-side
const distance = haversineDistance(userLat, userLng, taskLat, taskLng);
const allowed  = distance <= 100; // 100 meter radius
```

**Hub-and-Spoke Chat Enforcement**
- Supabase RLS `CHECK` constraint on `messages` table
- Frontend `ConversationList` only shows valid contacts by role
- Staff contact list is pre-filtered to managers/admins only

**Web Push without Firebase**
- VAPID keys generated locally (`node scripts/generate-vapid.js`)
- `web-push` npm package handles encryption
- Service Worker handles background notifications
- Expired subscriptions auto-cleaned from DB

---

## 📦 Tech Stack

| Layer | Technology | Cost |
|---|---|---|
| Database | Supabase PostgreSQL | Free |
| Auth | Supabase Auth | Free |
| Realtime | Supabase Realtime | Free |
| Backend | Node.js + Express | Free (self-hosted) |
| Frontend | Next.js + Tailwind | Free |
| Maps | Leaflet + OpenStreetMap | Free |
| Push | Web Push API (VAPID) | Free |
| Hosting (FE) | Vercel | Free tier |
| Hosting (BE) | Railway/Render | Free tier |

**Total cost: $0/month** 🎉

#!/usr/bin/env node
// scripts/generate-vapid.js — Run once to generate VAPID keys
// Usage: node scripts/generate-vapid.js
const webpush = require('web-push');
const keys = webpush.generateVAPIDKeys();
console.log('\n✅ VAPID Keys Generated — Add to your .env file:\n');
console.log(`VAPID_PUBLIC_KEY=${keys.publicKey}`);
console.log(`VAPID_PRIVATE_KEY=${keys.privateKey}`);
console.log(`VAPID_EMAIL=your@email.com\n`);

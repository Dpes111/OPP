// routes/attendance.js — Check-in + Geofence Verification
const router = require('express').Router();
const { supabase, requireAuth, requireRole } = require('../lib/supabase');
const { isWithinGeofence } = require('../lib/geofence');

// POST /api/attendance/checkin — Staff checks in at a task location
router.post('/checkin', requireAuth, async (req, res) => {
  try {
    const { task_id, latitude, longitude, notes } = req.body;

    if (!latitude || !longitude) {
      return res.status(400).json({ error: 'GPS coordinates required' });
    }

    let geofenceResult = { isWithin: true, distanceMeters: 0 };

    // If checking in against a specific task, validate geofence
    if (task_id) {
      const { data: task, error: taskErr } = await supabase
        .from('tasks')
        .select('id, latitude, longitude, location_name, assigned_to, status')
        .eq('id', task_id)
        .single();

      if (taskErr || !task) {
        return res.status(404).json({ error: 'Task not found' });
      }
      if (task.assigned_to !== req.user.id) {
        return res.status(403).json({ error: 'This task is not assigned to you' });
      }

      geofenceResult = isWithinGeofence(
        parseFloat(latitude), parseFloat(longitude),
        task.latitude, task.longitude,
        100 // 100-meter fence radius
      );

      // Update task to in_progress if within fence
      if (geofenceResult.isWithin && task.status === 'assigned') {
        await supabase
          .from('tasks')
          .update({ status: 'in_progress' })
          .eq('id', task_id);
      }
    }

    // Log the check-in
    const { data: log, error: logErr } = await supabase
      .from('attendance_logs')
      .insert({
        staff_id: req.user.id,
        task_id: task_id || null,
        check_in_lat: parseFloat(latitude),
        check_in_lng: parseFloat(longitude),
        distance_meters: geofenceResult.distanceMeters,
        is_within_fence: geofenceResult.isWithin,
        notes: notes || null,
      })
      .select()
      .single();

    if (logErr) throw logErr;

    res.status(201).json({
      log,
      geofence: geofenceResult,
      message: geofenceResult.isWithin
        ? '✅ Check-in successful — you are within the task zone.'
        : `⚠️ You are ${geofenceResult.distanceMeters}m away from the task location (limit: 100m).`,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/attendance/complete — Mark task complete (requires geofence pass)
router.post('/complete', requireAuth, async (req, res) => {
  try {
    const { task_id, latitude, longitude } = req.body;

    if (!task_id || !latitude || !longitude) {
      return res.status(400).json({ error: 'task_id and GPS coordinates required' });
    }

    const { data: task, error: taskErr } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', task_id)
      .single();

    if (taskErr || !task) return res.status(404).json({ error: 'Task not found' });
    if (task.assigned_to !== req.user.id) return res.status(403).json({ error: 'Not your task' });

    // Geofence check REQUIRED to complete
    const { isWithin, distanceMeters } = isWithinGeofence(
      parseFloat(latitude), parseFloat(longitude),
      task.latitude, task.longitude,
      100
    );

    if (!isWithin) {
      return res.status(400).json({
        error: `Cannot complete task — you are ${distanceMeters}m away from the location. Must be within 100m.`,
        distanceMeters,
      });
    }

    // Mark task complete
    const { data: updated, error: updateErr } = await supabase
      .from('tasks')
      .update({ status: 'completed', completed_at: new Date().toISOString() })
      .eq('id', task_id)
      .select()
      .single();

    if (updateErr) throw updateErr;

    // Log final check-in
    await supabase.from('attendance_logs').insert({
      staff_id: req.user.id,
      task_id,
      check_in_lat: parseFloat(latitude),
      check_in_lng: parseFloat(longitude),
      distance_meters: distanceMeters,
      is_within_fence: true,
      notes: 'Task completed',
    });

    res.json({
      task: updated,
      message: '✅ Task marked as completed successfully!',
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/attendance — View attendance logs
router.get('/', requireAuth, async (req, res) => {
  try {
    let query = supabase
      .from('attendance_logs')
      .select(`
        *,
        staff:profiles!attendance_logs_staff_id_fkey(id, full_name, email),
        task:tasks(id, title, type, location_name)
      `)
      .order('check_in_time', { ascending: false })
      .limit(200);

    if (req.user.role === 'staff') {
      query = query.eq('staff_id', req.user.id);
    }

    const { data, error } = await query;
    if (error) throw error;
    res.json({ logs: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

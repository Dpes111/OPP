// routes/auth.js — User management (Admin only)
const router = require('express').Router();
const { supabase, requireAuth, requireRole } = require('../lib/supabase');

// GET /api/auth/users — List all users (admin/manager)
router.get('/users', requireAuth, requireRole('admin', 'manager'), async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, role, is_active, created_at, phone')
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json({ users: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/users — Create a new user (admin only)
router.post('/users', requireAuth, requireRole('admin'), async (req, res) => {
  try {
    const { email, password, full_name, role, phone } = req.body;
    if (!email || !password || !full_name || !role) {
      return res.status(400).json({ error: 'email, password, full_name, role required' });
    }
    if (!['admin', 'manager', 'staff'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Create auth user
    const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name, role },
    });

    if (authErr) throw authErr;

    // Update profile with phone if provided
    if (phone) {
      await supabase.from('profiles').update({ phone }).eq('id', authData.user.id);
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authData.user.id)
      .single();

    res.status(201).json({ user: profile });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/auth/users/:id — Update user
router.patch('/users/:id', requireAuth, requireRole('admin'), async (req, res) => {
  try {
    const { full_name, role, is_active, phone } = req.body;
    const updates = {};
    if (full_name !== undefined) updates.full_name = full_name;
    if (role !== undefined) updates.role = role;
    if (is_active !== undefined) updates.is_active = is_active;
    if (phone !== undefined) updates.phone = phone;

    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) throw error;
    res.json({ user: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/auth/users/:id — Deactivate user (admin only)
router.delete('/users/:id', requireAuth, requireRole('admin'), async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: 'Cannot deactivate your own account' });
    }
    await supabase.from('profiles').update({ is_active: false }).eq('id', req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

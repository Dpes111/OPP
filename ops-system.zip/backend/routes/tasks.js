// routes/tasks.js — Task CRUD + Assignment
const router = require('express').Router();
const { supabase, requireAuth, requireRole } = require('../lib/supabase');
const { sendPushToUser } = require('../lib/pushService');

// GET /api/tasks — Fetch tasks (RLS handles filtering by role)
router.get('/', requireAuth, async (req, res) => {
  try {
    let query = supabase
      .from('tasks')
      .select(`
        *,
        assigned_to_profile:profiles!tasks_assigned_to_fkey(id, full_name, email, role),
        assigned_by_profile:profiles!tasks_assigned_by_fkey(id, full_name, role)
      `)
      .order('created_at', { ascending: false });

    // Staff: only their tasks
    if (req.user.role === 'staff') {
      query = query.eq('assigned_to', req.user.id);
    }

    const { data, error } = await query;
    if (error) throw error;
    res.json({ tasks: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/tasks/staff-workload — Active task count per staff member
router.get('/staff-workload', requireAuth, requireRole('admin', 'manager'), async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .select('assigned_to, status, assigned_to_profile:profiles!tasks_assigned_to_fkey(id, full_name)')
      .in('status', ['assigned', 'in_progress'])
      .not('assigned_to', 'is', null);

    if (error) throw error;

    // Aggregate counts
    const workload = {};
    for (const task of data) {
      const id = task.assigned_to;
      if (!workload[id]) {
        workload[id] = {
          staff_id: id,
          full_name: task.assigned_to_profile?.full_name,
          active_count: 0,
        };
      }
      workload[id].active_count++;
    }

    res.json({ workload: Object.values(workload) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/tasks — Create & assign a task
router.post('/', requireAuth, requireRole('admin', 'manager'), async (req, res) => {
  try {
    const {
      title, type, description,
      location_name, latitude, longitude,
      assigned_to, due_date,
    } = req.body;

    if (!title || !type || !location_name || !latitude || !longitude) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    if (!['bank', 'delivery', 'party'].includes(type)) {
      return res.status(400).json({ error: 'Invalid task type' });
    }

    const { data: task, error } = await supabase
      .from('tasks')
      .insert({
        title, type, description,
        location_name,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        assigned_to: assigned_to || null,
        assigned_by: req.user.id,
        status: assigned_to ? 'assigned' : 'pending',
        due_date: due_date || null,
      })
      .select()
      .single();

    if (error) throw error;

    // Send push notification to assigned staff
    if (assigned_to) {
      const taskTypeLabel = { bank: '🏦 Bank Deposit', delivery: '📦 Delivery', party: '🎉 Party Visit' };
      await sendPushToUser(assigned_to, {
        title: 'New Task Assigned',
        body: `${taskTypeLabel[type] || type}: ${title} at ${location_name}`,
        tag: `task-${task.id}`,
        data: { taskId: task.id, url: '/tasks' },
      });
    }

    res.status(201).json({ task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/tasks/:id — Update task (status, reassign, etc.)
router.patch('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Staff can only update status of their own tasks
    if (req.user.role === 'staff') {
      const allowed = ['status'];
      const keys = Object.keys(updates);
      if (keys.some(k => !allowed.includes(k))) {
        return res.status(403).json({ error: 'Staff can only update task status' });
      }
      if (updates.status && !['in_progress', 'completed'].includes(updates.status)) {
        return res.status(400).json({ error: 'Invalid status transition' });
      }
    }

    if (updates.status === 'completed') {
      updates.completed_at = new Date().toISOString();
    }

    const { data: task, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Notify manager/admin if staff completed a task
    if (updates.status === 'completed' && task.assigned_by) {
      await sendPushToUser(task.assigned_by, {
        title: '✅ Task Completed',
        body: `${task.title} has been marked complete by staff.`,
        tag: `complete-${task.id}`,
        data: { taskId: task.id, url: '/tasks' },
      });
    }

    res.json({ task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', requireAuth, requireRole('admin', 'manager'), async (req, res) => {
  try {
    const { error } = await supabase.from('tasks').delete().eq('id', req.params.id);
    if (error) throw error;
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
